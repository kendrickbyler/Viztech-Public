Hi. This is a read me.

Some terms first.

VF = Viztech Furniture aka Source site where all the original products come from\
CS - Current Site where the plugin is installed

<h2>TODO</h2>

- [x] When the product exists on the <strong>CS</strong> already, don't sync categories. Only sync categories if it's a new product.
- [x] Make an option to force syncing categories at all times, even if it's an update and not just a new product.
- [x] Edit the function that imports images, to only import new images to avoid duplicate images being imported.
- [x] Make so there's an option to not sync "short description".
- [x] Make so there's an option to only sync "design center" products.
- [x] Make so plugin syncs products automatically, periodially - like once a week.
- [x] Make sure data is properly sanitized
- [ ] Make sure when looking to pull data from VF furniture that the url is properly formed before trying to get data
- [x] Clean up UX
- [x] Setup Update Server
- [ ] Make so products are created right away after they are retrieved from VF, on a product by product basis. 
 
<h2>Features</h2>

- [ ] Tool to make so the plugin loops through the current variable aka design center products and make sure all of the variations are current.
- [ ] Tool to make so a certain category can be removed easily.
- [ ] Tool to make so you can import a certain builder category manually.

Signed,\
Un hombre