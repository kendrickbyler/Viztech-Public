<?php
/**
 * Settings class file.
 *
 * @package WordPress Plugin Template/Settings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings class.
 */
class viztech_api_Settings {

	/**
	 * The single instance of viztech_api_Settings.
	 *
	 * @var     object
	 * @access  private
	 * @since   1.0.0
	 */
	private static $_instance = null; //phpcs:ignore

	/**
	 * The main plugin object.
	 *
	 * @var     object
	 * @access  public
	 * @since   1.0.0
	 */
	public $parent = null;

	/**
	 * Prefix for plugin settings.
	 *
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $base = '';

	/**
	 * Available settings for plugin.
	 *
	 * @var     array
	 * @access  public
	 * @since   1.0.0
	 */
	public $settings = array();

	/**
	 * Constructor function.
	 *
	 * @param object $parent Parent object.
	 */
	public function __construct( $parent ) {
		$this->parent = $parent;

		$this->base = 'wpt_';

		// Initialise settings.
		add_action( 'init', array( $this, 'init_settings' ), 11 );

		// Register plugin settings.
		add_action( 'admin_init', array( $this, 'register_settings' ) );

		// Add settings page to menu.
		add_action( 'admin_menu', array( $this, 'add_menu_item' ) );

		// Add settings link to plugins page.
		add_filter(
			'plugin_action_links_' . plugin_basename( $this->parent->file ),
			array(
				$this,
				'add_settings_link',
			)
		);	

		add_filter( 'action_scheduler_retention_period',  array( $this, 'wpb_action_scheduler_purge' ) );

		// Get All Builders Category and store in options
		add_action( 'get_all_builders_ac', array( $this, 'get_all_builders' ) );
		
		
		// Configure placement of plugin settings page. See readme for implementation.
		add_filter( $this->base . 'menu_settings', array( $this, 'configure_settings' ) );

	}

	public function wpb_action_scheduler_purge() {
		return DAY_IN_SECONDS;
	}
	

	
	/**
	 * Initialise settings
	 *
	 * @return void
	 */
	public function init_settings() {
		$this->settings = $this->settings_fields();

		// if ( class_exists( 'ActionScheduler' ) ) {
		// 	remove_action( 'action_scheduler_run_queue', array( ActionScheduler::runner(), 'run' ) );
		// }

	}

	/**
	 * Add settings page to admin menu
	 *
	 * @return void
	 */
	public function add_menu_item() {

		$args = $this->menu_settings();

		// Do nothing if wrong location key is set.
		if ( is_array( $args ) && isset( $args['location'] ) && function_exists( 'add_' . $args['location'] . '_page' ) ) {
			switch ( $args['location'] ) {
				case 'options':
				case 'submenu':
					$page = add_submenu_page( $args['parent_slug'], $args['page_title'], $args['menu_title'], $args['capability'], $args['menu_slug'], $args['function'] );
					break;
				case 'menu':
					$page = add_menu_page( $args['page_title'], $args['menu_title'], $args['capability'], $args['menu_slug'], $args['function'], $args['icon_url'], $args['position'] );
					break;
				default:
					return;
			}
			add_action( 'admin_print_styles-' . $page, array( $this, 'settings_assets' ) );
		}
	}

	/**
	 * Prepare default settings page arguments
	 *
	 * @return mixed|void
	 */
	private function menu_settings() {
		return apply_filters(
			$this->base . 'menu_settings',
			array(
				'location'    => 'options', // Possible settings: options, menu, submenu.
				'parent_slug' => 'options-general.php',
				'page_title'  => __( 'Viztech API', 'viztech-api' ),
				'menu_title'  => __( 'Viztech API', 'viztech-api' ),
				'capability'  => 'manage_options',
				'menu_slug'   => $this->parent->_token . '_settings',
				'function'    => array( $this, 'settings_page' ),
				'icon_url'    => '',
				'position'    => null,
			)
		);
	}

	/**
	 * Container for settings page arguments
	 *
	 * @param array $settings Settings array.
	 *
	 * @return array
	 */
	public function configure_settings( $settings = array() ) {
		return $settings;
	}

	/**
	 * Load settings JS & CSS
	 *
	 * @return void
	 */
	public function settings_assets() {

		// We're including the farbtastic script & styles here because they're needed for the colour picker
		// If you're not including a colour picker field then you can leave these calls out as well as the farbtastic dependency for the wpt-admin-js script below.
		wp_enqueue_style( 'farbtastic' );
		wp_enqueue_script( 'farbtastic' );

		// We're including the WP media scripts here because they're needed for the image upload field.
		// If you're not including an image upload then you can leave this function call out.
		wp_enqueue_media();

		wp_register_script( $this->parent->_token . '-settings-js', $this->parent->assets_url . 'js/settings' . $this->parent->script_suffix . '.js', array( 'farbtastic', 'jquery' ), '1.0.0', true );
		wp_enqueue_script( $this->parent->_token . '-settings-js' );
	}

	/**
	 * Add settings link to plugin list table
	 *
	 * @param  array $links Existing links.
	 * @return array        Modified links.
	 */
	public function add_settings_link( $links ) {
		$settings_link = '<a href="options-general.php?page=' . $this->parent->_token . '_settings">' . __( 'Settings', 'viztech-api' ) . '</a>';
		array_push( $links, $settings_link );
		return $links;
	}

	/**
	 * Build settings fields
	 *
	 * @return array Fields to be displayed on settings page
	 */
	private function settings_fields() {

		$builders = [];

		$builders = json_decode(get_option('builder_categories'));

		$builders = ( ! empty( $builders ) ) ? $builders : array();

		$builder_option = [];

		foreach ( $builders as $builder ) {
			
			$builder_option[$builder->id] = $builder->name;

		}

		$all_builders = $this->get_builders_settings();

		$prices_per_builder = [];

		foreach ( $all_builders as $sel_builder ) {

			$found_key = array_search($sel_builder, array_column($builders, 'id'));

			$selected = $builders[$found_key];

			$prices_per_builder[] = array(
				'id'          => 'vf_increase_price_builder' . $sel_builder,
				'label'       => __( 'Price change percentage for ' . $selected->name, 'viztech-api' ),
				'description' => __( 'Price change percentage. Enter 100.00 for a 100% increase, or, if you want to increase by 50%, enter 50.00.', 'viztech-api' ),
				'type'        => 'number',
				'min'		  => '0',
				'step'		  => '0.01',			
				'default'     => '',
				'placeholder' => __( '', 'viztech-api' ),
			);

		}


		$settings['standard'] = array(
			'title'       => __( 'Viztech API Settings', 'viztech-api' ),
			'description' => __( 'Fill out the below fields to set up the API with this site.', 'viztech-api' ),
			'fields'      => array(
				// array(
				// 	'id'          => 'text_field',
				// 	'label'       => __( 'Some Text', 'viztech-api' ),
				// 	'description' => __( 'This is a standard text field.', 'viztech-api' ),
				// 	'type'        => 'text',
				// 	'default'     => '',
				// 	'placeholder' => __( 'Placeholder text', 'viztech-api' ),
				// ),
				array(
					'id'          => 'vf_api_key',
					'label'       => __( 'Viztech API Key', 'viztech-api' ),
					'description' => __( 'When you go to create the key on Viztech Furniture for this site, please select "Read Only" rights.', 'viztech-api' ),
					'type'        => 'text_secret',
					'default'     => '',
					'placeholder' => __( 'ck_bunch_of_gibberish', 'viztech-api' ),
				),
				array(
					'id'          => 'vf_api_secret',
					'label'       => __( 'Viztech API Secret', 'viztech-api' ),
					'description' => __( 'Viztech API Secret', 'viztech-api' ),
					'type'        => 'text_secret',
					'default'     => '',
					'placeholder' => __( 'cs_bunch_of_gibberish', 'viztech-api' ),
				),
				array(
					'id'          => 'url_site_api',
					'label'       => __( 'Enter URL', 'viztech-api' ),
					'description' => __( 'Enter URL of Viztech Furniture', 'viztech-api' ),
					'type'        => 'url',
					'callback'	  => 'esc_url_raw',
					'default'     => '',
					'placeholder' => __( 'EX: https://viztechfurniture.com', 'viztech-api' ),
				),
				array(
					'id'          => 'vf_builders_id',
					'label'       => __( 'VF Builder Category Id', 'viztech-api' ),
					'description' => __( 'We need to get the main builder category from Viztech Furniture, this is the data that the API tried to get. If the data looks correct, please enter the id of the field into the number field. If it\'s incorrect, please go to Viztech Furniture and find the proper id of the "Builders" category.', 'viztech-api' ),
					'type'        => 'number',
					'default'     => '',
					'placeholder' => __( '', 'viztech-api' ),
				),
				array(
					'id'          => 'vf_sync_categories',
					'label'       => __( 'Category Syncing Options', 'viztech-api' ),
					'description' => __( 'You have several options when it comes to syncing categories. By default, categories are always synced. There are some other options as well.', 'viztech-api' ),
					'type'        => 'radio',
					'options'     => array(
						'always_sync'    => 'ALWAYS sync (default)',
						'new_product'  => 'Only New Products',
						'never_sync'    => 'Never sync',
					),
					'default'     => 'always_sync',
				),
				array(
					'id'          => 'vf_design_center_products',
					'label'       => __( 'Design Center Options', 'viztech-api' ),
					'description' => __( 'Select what products you want to sync. You can choose to sync Design Center only products, Non Design Center Products, or, by default, BOTH Design Center and Non Design Center Products', 'viztech-api' ),
					'type'        => 'radio',
					'options'     => array(
						'all_products'  => 'All Products (default)',
						'design_center_only'    => 'Design Center Products Only',
						'non_design_center_products'    => 'Non Design Center Products',
					),
					'default'     => 'all_products',
				),			
				array(
					'id'          => 'vf_sync_short_description',
					'label'       => __( 'Do not sync product "short description"', 'viztech-api' ),
					'description' => __( 'By default the product "short description" is synced, check this box if you do not want to sync the product "short description".', 'viztech-api' ),
					'type'        => 'checkbox',
				),
				array(
					'id'          => 'vf_sync_everything',
					'label'       => __( 'Sync all products', 'viztech-api' ),
					'description' => __( 'Sync all products, mostly for the Kiosk. If you check this setting, whatever you select below won\'t be honored.', 'viztech-api' ),
					'type'        => 'checkbox',
				),
				array(
					'id'          => 'vf_builders',
					'label'       => __( 'Viztech Builders', 'viztech-api' ),
					'description' => __( 'You can select multiple builders from Viztech Furniture.', 'viztech-api' ),
					'type'        => 'select_multi',
					'options'     => $builder_option,
				),
				array(
					'id'          => 'vf_sync_price',
					'label'       => __( 'Not sync pricing', 'viztech-api' ),
					'description' => __( 'Not sync pricing. By default pricing is synced.', 'viztech-api' ),
					'type'        => 'checkbox',
				),
				array(
					'id'          => 'vf_increase_price',
					'label'       => __( 'Price change percentage', 'viztech-api' ),
					'description' => __( 'Price change percentage. Enter 100.00 for a 100% increase, or, if you want to increase by 50%, enter 50.00.', 'viztech-api' ),
					'type'        => 'number',
					'min'		  => '0',
					'step'		  => '0.01',			
					'default'     => '',
					'placeholder' => __( '', 'viztech-api' ),
				),
				array(
					'id'          => 'custom_html_a',
					'type'        => 'custom_html_a',
					'label'       => __( 'Builder Price Increase', 'viztech-api' ),
				),
		
			),
		);

		$settings['tools'] = array(
			'title'       => __( 'Tools', 'viztech-api' ),
			'description' => __( 'These are some extra input fields that maybe aren\'t as common as the others.', 'viztech-api' ),
		);

	
		$old_fields = array();

		$old_fields = $settings['standard']['fields'];

		foreach ( $prices_per_builder as $field ) {

			$old_fields[] = $field;

		}


		$settings['standard']['fields'] = $old_fields;
	
		$settings = apply_filters( $this->parent->_token . '_settings_fields', $settings );

		return $settings;
	}



	/**
	 * Register plugin settings
	 *
	 * @return void
	 */
	public function register_settings() {
		if ( is_array( $this->settings ) ) {

			// Check posted/selected tab.
			//phpcs:disable
			$current_section = '';
			if ( isset( $_POST['tab'] ) && $_POST['tab'] ) {
				$current_section = $_POST['tab'];
			} else {
				if ( isset( $_GET['tab'] ) && $_GET['tab'] ) {
					$current_section = $_GET['tab'];
				}
			}

			if ( isset( $_GET['tab'] ) ) { 
				if ( $_GET['tab']  === 'tools' ) {
					return;
				}
			}

			//phpcs:enable

			foreach ( $this->settings as $section => $data ) {

				if ( $current_section && $current_section !== $section ) {
					continue;
				}

				// Add section to page.
				add_settings_section( $section, $data['title'], array( $this, 'settings_section' ), $this->parent->_token . '_settings' );
	
				foreach ( $data['fields'] as $field ) {
					
					// Validation callback for field.
					$validation = '';
					if ( isset( $field['callback'] ) ) {
						$validation = $field['callback'];
					}


					// Register field.
					$option_name = $this->base . $field['id'];
					register_setting( $this->parent->_token . '_settings', $option_name, $validation );

					// Add field to page.
					add_settings_field(
						$field['id'],
						$field['label'],
						array( $this->parent->admin, 'display_field' ),
						$this->parent->_token . '_settings',
						$section,
						array(
							'field'  => $field,
							'prefix' => $this->base,
						)
					);
				}

				if ( ! $current_section ) {
					break;
				}
			}
		}
	}
	
	
    function get_builders_settings() {

        $all_selected_builders = array();

        $all_selected_builders = get_option('wpt_vf_builders');

        $all_builders_option = get_option('wpt_vf_sync_everything');

        $all_builders = array();

        $all_builders = json_decode(get_option('builder_categories'));

        $builders = array();

        $builders = 'on' === $all_builders_option ? wp_list_pluck( $all_builders, 'id' ) : $all_selected_builders;

        return $builders;

    }


	/**
	 * Settings section.
	 *
	 * @param array $section Getting all builders categories
	 * @return void
	 */

	public function get_all_builders() {

		$client_api = new Woo_Client_API();

        $builderCat = (string) get_option('wpt_vf_builders_id');

		$data = array();
			  
		$data = array('parent' => $builderCat);
	  
		$builder_data = json_decode($client_api->woo_getter( 'products/categories', $data ),true);

		if ( $builder_data ) {
			update_option('builder_categories', json_encode($builder_data, JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS), 'no');
		}

    }

	/**
	 * Settings section.
	 *
	 * @param array $section Array of section ids.
	 * @return void
	 */
	public function settings_section( $section ) {
		$html = '<p> ' . $this->settings[ $section['id'] ]['description'] . '</p>' . "\n";
		echo $html; //phpcs:ignore
	}

	/**
	 * Load settings page content.
	 *
	 * @return void
	 */
	public function settings_page() {

		// Build page HTML.
		$html      = '<div class="wrap" id="' . $this->parent->_token . '_settings">' . "\n";
			$html .= '<h2>' . __( 'Viztech API', 'viztech-api' ) . '</h2>' . "\n";

			$tab = '';
		//phpcs:disable
		if ( isset( $_GET['tab'] ) && $_GET['tab'] ) {
			$tab .= $_GET['tab'];
		}
		//phpcs:enable

		// Show page tabs.
		if ( is_array( $this->settings ) && 1 < count( $this->settings ) ) {

			$html .= '<h2 class="nav-tab-wrapper">' . "\n";

			$c = 0;
			foreach ( $this->settings as $section => $data ) {

				// Set tab class.
				$class = 'nav-tab';
				if ( ! isset( $_GET['tab'] ) ) { //phpcs:ignore
					if ( 0 === $c ) {
						$class .= ' nav-tab-active';
					}
				} else {
					if ( isset( $_GET['tab'] ) && $section == $_GET['tab'] ) { //phpcs:ignore
						$class .= ' nav-tab-active';
					}
				}

				// Set tab link.
				$tab_link = add_query_arg( array( 'tab' => $section ) );
				if ( isset( $_GET['settings-updated'] ) ) { //phpcs:ignore
					$tab_link = remove_query_arg( 'settings-updated', $tab_link );
				}

				// Output tab.
				$html .= '<a href="' . $tab_link . '" class="' . esc_attr( $class ) . '">' . esc_html( $data['title'] ) . '</a>' . "\n";

				++$c;
			}

			$html .= '</h2>' . "\n";
		}

		 if ( strtolower($_GET['tab']) !== 'tools' ) {

			$html .= '<form method="post" action="options.php" enctype="multipart/form-data">' . "\n";

				// Get settings fields.
				ob_start();
				settings_fields( $this->parent->_token . '_settings' );
				do_settings_sections( $this->parent->_token . '_settings' );
				$html .= ob_get_clean();

				$html     .= '<p class="submit">' . "\n";
					$html .= '<input type="hidden" name="tab" value="' . esc_attr( $tab ) . '" />' . "\n";
					$html .= '<input name="Submit" type="submit" class="button-primary" value="' . esc_attr( __( 'Save Settings', 'viztech-api' ) ) . '" />' . "\n";
				$html     .= '</p>' . "\n";
			$html         .= '</form>' . "\n";
		} else {
			$html .= require_once 'html/html-tools.php';
		}
		$html             .= '</div>' . "\n";

		echo $html; //phpcs:ignore
	}

	/**
	 * Main viztech_api_Settings Instance
	 *
	 * Ensures only one instance of viztech_api_Settings is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 * @static
	 * @see viztech_api()
	 * @param object $parent Object instance.
	 * @return object viztech_api_Settings instance
	 */
	public static function instance( $parent ) {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self( $parent );
		}
		return self::$_instance;
	} // End instance()

	/**
	 * Cloning is forbidden.
	 *
	 * @since 1.0.0
	 */
	public function __clone() {
		_doing_it_wrong( __FUNCTION__, esc_html( __( 'Cloning of viztech_api_API is forbidden.' ) ), esc_attr( $this->parent->_version ) );
	} // End __clone()

	/**
	 * Unserializing instances of this class is forbidden.
	 *
	 * @since 1.0.0
	 */
	public function __wakeup() {
		_doing_it_wrong( __FUNCTION__, esc_html( __( 'Unserializing instances of viztech_api_API is forbidden.' ) ), esc_attr( $this->parent->_version ) );
	} // End __wakeup()

}
