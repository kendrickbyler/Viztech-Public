<?php

// simple html and php for the triggers tab

ob_start();

$getting_prods = new viztech_api_get_product_data();

$formatting_prods = new viztech_api_format_products();

$creating_prods = new viztech_api_create_products();

$syncing_terms_cats = new viztech_api_terms_categories();

$deleting_prods = new viztech_api_delete_products();

$builders = $getting_prods->get_builders();

$all_builders = json_decode(get_option('builder_categories'));

$all_builders = ( ! empty( $all_builders ) ) ? $all_builders : array();

?>
<br>
<form  method="post">
    <input type="submit" name="get_builders" value="get all builders" >
</form>


<form method="post">
    <input type="submit" name="get_prods" value="get products" >
</form>

<h2>Create products from builders</h2>

<form method="post">
<select name="vf_create_builders[]" id="create_builders" multiple="multiple">
<?php

    foreach ( $builders as $bil ) {

        $found_key = array_search($bil, array_column($all_builders, 'id'));

        $selected = $all_builders[$found_key];

        echo '<option value="'.$bil.'">'.$selected->name.'</option>';

    } 


?>
 

</select>
<br>
<br>

<input type="submit" name="submit_get_create" value="get and create products from builder" >

<input type="submit" name="submit_get_data" value="get products from builder" >

<input type="submit" name="submit_create_data" value="create products from builder" >

</form>

<br>

<form method="post">
    <p>Enter Exception SKU's, enter one at a time or comma seperated.</p>
    <input type="text" name="exception_skus" placeholder="enter exception skus">
    <input type="submit" name="exception_skus_submit" value="submit" >
</form>

<form method="post">
    <input type="submit" name="rest_prods" value="create products" >
</form>

<form method="post" onsubmit="return confirm('Are you sure you want to delete everything?');">
    <input type="submit" name="delete_all" value="delete all" >
</form>

<form method="post" onsubmit="return confirm('Are you sure you want to delete all images?');">
    <input type="submit" name="delete_images" value="delete images" >
</form>

<form method="post">
    <input type="submit" name="cancel_creating" value="cancel creating" >
</form>

<form method="post">
    <input type="submit" name="clear_crons" value="clear cron jobs" >
</form>

<form method="post">
    <input type="submit" name="get_vf_ids" value="get vf ids - careful" >
</form>


<br>

<p>Select Builders to Delete (be careful)</p>

<?php

$builder = get_term_by('slug', 'builders', 'product_cat');

$builder_id = $builder->term_id;

$args = array(

    'child_of'  => $builder_id,
    'taxonomy' => 'product_cat'

);

$cats = get_categories($args);

if ( $cats ) {

?>

<form method="post" onsubmit="return confirm('Are you sure you want to delete these products?');">
<select name="vf_delete_builders[]" id="delete_builders" multiple="multiple">
<?php

    foreach ( $cats as $cat ) {

        echo '<option value="'.$cat->slug.'">'.$cat->name.'</option>';

    } 

}

?>
 

</select>
<br>
<br>
<input type="submit" name="submit_delete" value="submit delete builders" >
</form>
<br>
<br>

<?php


$all_products = ( ! empty(json_decode(get_option('create_products'),true)) ) ? json_decode(get_option('create_products'),true) : array();

$all_products_raw = ( ! empty(json_decode(get_option('products_raw'),true)) ) ? json_decode(get_option('products_raw'),true) : array();

$all_products_cleaned =  ( ! empty(json_decode(get_option('all_products_new'),true)) ) ?  json_decode(get_option('all_products_new'),true) : array();

$terms =  ( ! empty(json_decode(get_option('all_terms'),true)) ) ? json_decode(get_option('all_terms'),true): array() ;

$existing_terms = array();
      
$existing_terms = ( empty(get_option('vf_cats') ) ) ? array() : json_decode( get_option('vf_cats'), true );

$cats_raw = ( ! empty(json_decode(get_option('all_cats_raw'),true)) ) ? json_decode(get_option('all_cats_raw'),true) : array();

$prods = array();

$product = array();

foreach ( $builders as $sel_builder ) {

    $found_key = array_search($sel_builder, array_column($all_builders, 'id'));

    $selected = $all_builders[$found_key];

    $index = 'products_'.$sel_builder;

    $products = json_decode( get_option( $index ),true );    

    $products = ! empty($products) ? $products : array();

    // echo '<pre>';

    // print_r($products);

    // echo '</pre>';

    $prods[] = count( $products );

    echo count($products) . ' ' . $sel_builder . ' ' . $selected->name . '<br>';

}

echo 'sum: ' . array_sum($prods) . '<br>';


?>


<?php

if(isset($_POST['exception_skus']) && isset( $_POST['exception_skus_submit'] ) ){

    $old_exception_skus = json_decode(get_option( 'vf_sku_exceptions' ), true);

    $old_exception_skus = ! empty($old_exception_skus) ? $old_exception_skus : array();

    $post_exception = sanitize_text_field( $_POST['exception_skus'] );

    $post_exception = str_replace(' ', '', $post_exception);

    $new_exception = array();

    $new_exception = explode(',', $post_exception);

    $all_exception_skus = array_merge($old_exception_skus, $new_exception);

    update_option('vf_sku_exceptions', json_encode($all_exception_skus));

}

if(isset($_POST['submit_get_create']) ){
 
    $vals = $_POST['vf_create_builders'];

    $builders = array();

    foreach ( $vals as $builder_id ) {

      $builders[] = $builder_id;  

      $hook = 'replace_cats_atts_ac';

      $args = array();

      $args =  array( (int) $builder_id, true );

      $if_has_scheduled = as_has_scheduled_action( $hook, $args );

      if ( false === $if_has_scheduled ) {
        as_schedule_single_action( time() + 10800, $hook, $args );
      }

    }

    $getting_prods->get_products_ini( $builders );

}

if(isset($_POST['submit_get_data']) ){
 
    $vals = $_POST['vf_create_builders'];

    $builders = array();

    foreach ( $vals as $builder_id ) {

        $builders[] = $builder_id;

    }

    $getting_prods->get_products_ini( $builders );

}

if(isset($_POST['submit_create_data']) ){
 
    $vals = $_POST['vf_create_builders'];

    foreach ( $vals as $builder_id ) {

        $hook = 'replace_cats_atts_ac';

        $args = array();

        $args = array( (int) $builder_id, true );

        $if_has_scheduled = as_has_scheduled_action( $hook, $args );

        if ( false === $if_has_scheduled ) {
            as_schedule_single_action( time() + 30, 'replace_cats_atts_ac', $args );
        }

    }

}


if(isset($_POST['vf_delete_builders'])){
 
    $vals = $_POST['vf_delete_builders'];
   

    foreach ( $vals as $builder_id ) {

        $builder_arr = array();

        $builder_arr = array( $builder_id );

        as_enqueue_async_action( 'delete_products_builder_ac', $builder_arr );
    }

}



if(isset($_POST['get_specific_builders']) && isset( $_POST['get_builder_id'] ) ){
 
    $builder_id = (int) $_POST['get_builder_id'];

    $getting_prods->get_products_ini( array( $builder_id ) );

}


if(isset($_POST['create_specific_builders']) && isset( $_POST['get_builder_id'] ) ){
 
    $builder_id = (int) $_POST['get_builder_id'];

    as_enqueue_async_action( 'replace_cats_atts_ac', array( $builder_id ) );

}

if(isset($_POST['rest_prods'])){
 
    $syncing_terms_cats->replace_categories_ini();

}


if(isset($_POST['get_builders'])){
 
    as_enqueue_async_action( 'get_all_builders_ac' );

}

if(isset($_POST['get_prods'])){
     
    as_enqueue_async_action( 'get_products_ini_ac' );

    // as_enqueue_async_action( 'get_all_builders_ac' );
    
}



if(isset($_POST['delete_all'])){

    $deleting_prods->delete_all_products();

}

if(isset($_POST['delete_images'])){
    
    as_enqueue_async_action('delete_images_ac');

}


if(isset($_POST['get_vf_ids'])) {

    as_enqueue_async_action( 'get_vf_ids_ini_ac' );

 }


if(isset($_POST['cancel_creating'])){

    as_unschedule_all_actions( 'create_products_ac' );
    as_unschedule_all_actions( 'create_variations_ac' );
    as_unschedule_all_actions( 'get_variation_data_ini_ac' );
    as_unschedule_all_actions( 'get_terms_ac' );
    as_unschedule_all_actions( 'clean_data_ac' );
    as_unschedule_all_actions( 'check_amounts_ac' );
    as_unschedule_all_actions( 'get_product_data_ac' );
    as_unschedule_all_actions( 'get_terms_ini_ac' );
    as_unschedule_all_actions( 'get_product_data_ac' );
    as_unschedule_all_actions( 'create_variations_ac_ini' );
    as_unschedule_all_actions( 'get_variation_data_ac' );
    as_unschedule_all_actions( 'replace_cats_atts_ac' );
    
}

if(isset($_POST['clear_crons'])){

    $deleting_prods->delete_cronies();

    
}


return ob_get_clean();

?>