<?php
/**
 * Plugin Name: Viztech API
 * Version: 0.1.0
 * Plugin URI: https://github.com/viztech-360/viztech-api
 * GitHub Plugin URI: https://github.com/viztech-360/viztech-api
 * Description: Viztech Furniture API
 * Author: Viztech 360
 * Author URI: https://viztech360.com
 * Requires at least: 4.0
 * Tested up to: 4.0
 *
 * Text Domain: viztech-api
 * Domain Path: /lang/
 *
 * @package WordPress
 * @author Viztech
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load plugin class files.
require_once 'includes/class-viztech-api.php';
require_once 'admin/class-viztech-api-settings.php';
require_once 'updater/wp-package-updater/class-wp-package-updater.php';


// Load plugin libraries.
require_once 'admin/class-viztech-api-admin-api.php';
require_once 'includes/vendor/wc-api.php';

require_once 'includes/lib/class-viztech-api-create-products.php';
require_once 'includes/lib/class-viztech-api-delete-products.php';
require_once 'includes/lib/class-viztech-api-format-products.php';
require_once 'includes/lib/class-viztech-api-get-product-data.php';
require_once 'includes/lib/class-viztech-api-terms-categories.php';

// Threed files
//require_once 'includes/threed/threed-public-viewer.php';

// require_once 'includes/lib/class-viztech-api-post-type.php';
// require_once 'includes/lib/class-viztech-api-taxonomy.php';

/**
 * Returns the main instance of viztech_api to prevent the need to use globals.
 *
 * @since  1.0.0
 * @return object viztech_api
 */
function viztech_api() {

	$instance = viztech_api::instance( __FILE__, '0.1.0' );

	if ( is_null( $instance->settings ) ) {
		$instance->settings = viztech_api_Settings::instance( $instance );
	}

	return $instance;
}

viztech_api();