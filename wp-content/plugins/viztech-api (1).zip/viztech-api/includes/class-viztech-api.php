<?php
/**
 * Main plugin class file.
 *
 * @package WordPress Plugin Template/Includes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main plugin class.
 */
class viztech_api {

	/**
	 * The single instance of viztech_api.
	 *
	 * @var     object
	 * @access  private
	 * @since   1.0.0
	 */
	private static $_instance = null; //phpcs:ignore

	/**
	 * Local instance of viztech_api_Admin_API
	 *
	 * @var viztech_api_Admin_API|null
	 */
	public $admin = null;

	/**
	 * Settings class object
	 *
	 * @var     object
	 * @access  public
	 * @since   1.0.0
	 */
	public $settings = null;

	/**
	 * Threed class object
	 *
	 * @var     object
	 * @access  public
	 * @since   1.0.0
	 */
	public $threed = null;

	/**
	 * The version number.
	 *
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $_version; //phpcs:ignore

	/**
	 * The token.
	 *
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $_token; //phpcs:ignore

	/**
	 * The main plugin file.
	 *
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $file;

	/**
	 * The main plugin directory.
	 *
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $dir;

	/**
	 * The plugin assets directory.
	 *
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $assets_dir;

	/**
	 * The plugin assets URL.
	 *
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $assets_url;

	/**
	 * Suffix for JavaScripts.
	 *
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $script_suffix;


	/**
	 * Constructor funtion.
	 *
	 * @param string $file File constructor.
	 * @param string $version Plugin version.
	 */
	public function __construct( $file = '', $version = '0.1.0' ) {
		$this->_version = $version;
		$this->_token   = 'viztech_api';

		// Load plugin environment variables.
		$this->file       = $file;
		$this->dir        = dirname( $this->file );
		$this->assets_dir = trailingslashit( $this->dir ) . 'assets';
		$this->assets_url = esc_url( trailingslashit( plugins_url( '/assets/', $this->file ) ) );

		$this->script_suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		register_activation_hook( $this->file, array( $this, 'install' ) );
		
		register_deactivation_hook( $this->file, array( $this, 'deactivate' ) );

		// Load frontend JS & CSS.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ), 10 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ), 10 );

		// Load admin JS & CSS.
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ), 10, 1 );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_styles' ), 10, 1 );

		add_action('plugins_loaded', array( $this, 'check_version_do_updates' ), 10, 1 );

		add_filter( 'woocommerce_rest_allowed_image_mime_types', array( $this, 'more_mimes_to_exts' ), 10, 1 );


		// Load API for generic admin functions.
		if ( is_admin() ) {
			$this->admin = new viztech_api_Admin_API();
		}

		/** Enable plugin updates with license check **/
		$viztech_api = new WP_Package_Updater(
			'https://updates.viztech360.solutions',
			wp_normalize_path( plugin_dir_path(__DIR__) ) . 'viztech-api.php',
			wp_normalize_path( plugin_dir_path( __DIR__ ) ),
			true
		);


		// Handle localisation.
		$this->load_plugin_textdomain();
		add_action( 'init', array( $this, 'load_localisation' ), 0 );

		add_action( 'init', array( $this, 'register_shortcodes' ), 0 );
	
	} // End __construct ()


	/**
	 * Load frontend CSS.
	 *
	 * @access  public
	 * @return void
	 * @since   1.0.0
	 */
	public function enqueue_styles() {
		wp_register_style( $this->_token . '-frontend', esc_url( $this->assets_url ) . 'css/frontend.css', array(), $this->_version );
		wp_enqueue_style( $this->_token . '-frontend' );
	} // End enqueue_styles ()

	/**
	 * Load frontend Javascript.
	 *
	 * @access  public
	 * @return  void
	 * @since   1.0.0
	 */
	public function enqueue_scripts() {
		wp_register_script( $this->_token . '-frontend', esc_url( $this->assets_url ) . 'js/frontend' . $this->script_suffix . '.js', array( 'jquery' ), $this->_version, true );
		wp_enqueue_script( $this->_token . '-frontend' );
	} // End enqueue_scripts ()

	/**
	 * Admin enqueue style.
	 *
	 * @param string $hook Hook parameter.
	 *
	 * @return void
	 */
	public function admin_enqueue_styles( $hook = '' ) {
		wp_register_style( $this->_token . '-admin', esc_url( $this->assets_url ) . 'css/admin.css', array(), $this->_version );
		wp_enqueue_style( $this->_token . '-admin' );
	} // End admin_enqueue_styles ()

	/**
	 * Load admin Javascript.
	 *
	 * @access  public
	 *
	 * @param string $hook Hook parameter.
	 *
	 * @return  void
	 * @since   1.0.0
	 */
	public function admin_enqueue_scripts( $hook = '' ) {
		wp_register_script( $this->_token . '-admin', esc_url( $this->assets_url ) . 'js/admin' . $this->script_suffix . '.js', array( 'jquery' ), $this->_version, true );
		wp_enqueue_script( $this->_token . '-admin' );
	} // End admin_enqueue_scripts ()

	/**
	 * Load plugin localisation
	 *
	 * @access  public
	 * @return  void
	 * @since   1.0.0
	 */
	public function load_localisation() {
		load_plugin_textdomain( 'viztech-api', false, dirname( plugin_basename( $this->file ) ) . '/lang/' );
	} // End load_localisation ()


	/**
	 * 
	 * Register Shortcodes Used in Plugin
	 *
	 * @since 0.0.8
	 *
	 */

	public function register_shortcodes() {

		/**
		 * 
		 * Shortcode to display the swatches on the front end.
		 *
		 * @since 0.0.8
		 *
		 * @param array shortcode atts
		 */

		add_shortcode( 'swatch_api','swatch_api_frontend', 10, 1 );
	
		function swatch_api_frontend($atts){
			ob_start();

			$atts = shortcode_atts(array(
				'swatch_type' => '',
				'vendors' => null
			), $atts);
		
			$data = get_option('vf-swatch-' . sanitize_text_field($atts["swatch_type"]));
		
			if(!empty($data)){ ?>
	        <div class="swatches-grid-container">
			<?php 
				foreach($data as $swatch){
					$title = sanitize_text_field($swatch['title']['rendered']);
					$img_url = sanitize_url($swatch['_embedded']['wp:featuredmedia'][0]['media_details']['sizes']['full']['source_url']);
					$att_vendors = array_map('trim', explode(',', sanitize_text_field($atts['vendors'])));
					if(!empty($title) && strlen($title) > 1 && is_null($atts['vendors']) || array_intersect($swatch['tag_slugs'], $att_vendors)){ ?>
						<div class="swatch swatches-lightbox-link" href="<?php echo $img_url; ?>" data-caption="<?php echo $title; ?>" >
							<img src="<?php echo $img_url; ?>" alt="<?php echo $title; ?>">
							<p><?php echo $title; ?></p>
						</div>
					<?php }
				}
			?>
			</div>
			<?php } elseif(empty($data) && current_user_can('manage_options')){ ?>
				<div class="swatch-error-container">
					<p>There has been an error, check to make sure shortcode has been entered correctly. This error message is only visible to admin users</p>
				</div>
			<?php }
		
			?>
		
			<div class="swatches-lightbox">
				<span class="helper"></span>
				<div class="swatches-lightbox-content"><a href="#" class="swatches-lightbox-close">&#10005;</a><div class="swatches-lightbox-content-img"></div></div>
			</div>
		
			<?php 
		
			return ob_get_clean();
		}
				
	}

	/**
	 * Load plugin textdomain
	 *
	 * @access  public
	 * @return  void
	 * @since   1.0.0
	 */
	public function load_plugin_textdomain() {
		$domain = 'viztech-api';

		$locale = apply_filters( 'plugin_locale', get_locale(), $domain );

		load_textdomain( $domain, WP_LANG_DIR . '/' . $domain . '/' . $domain . '-' . $locale . '.mo' );
		load_plugin_textdomain( $domain, false, dirname( plugin_basename( $this->file ) ) . '/lang/' );
	} // End load_plugin_textdomain ()

	/**
	 * Main viztech_api Instance
	 *
	 * Ensures only one instance of viztech_api is loaded or can be loaded.
	 *
	 * @param string $file File instance.
	 * @param string $version Version parameter.
	 *
	 * @return Object viztech_api instance
	 * @see viztech_api()
	 * @since 1.0.0
	 * @static
	 */
	public static function instance( $file = '', $version = '0.0.8' ) {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self( $file, $version );
		}

		return self::$_instance;
	} // End instance ()

	/**
	 * Cloning is forbidden.
	 *
	 * @since 1.0.0
	 */
	public function __clone() {
		_doing_it_wrong( __FUNCTION__, esc_html( __( 'Cloning of viztech_api is forbidden' ) ), esc_attr( $this->_version ) );

	} // End __clone ()

	/**
	 * Unserializing instances of this class is forbidden.
	 *
	 * @since 1.0.0
	 */
	public function __wakeup() {
		_doing_it_wrong( __FUNCTION__, esc_html( __( 'Unserializing instances of viztech_api is forbidden' ) ), esc_attr( $this->_version ) );
	} // End __wakeup ()

	/**
	 * Installation. Runs on activation.
	 *
	 * @access  public
	 * @return  void
	 * @since   1.0.0
	 */
	public function install() {

		   // Require parent plugin
		   if ( ! is_plugin_active( 'woocommerce/woocommerce.php' ) and current_user_can( 'activate_plugins' ) ) {
			// Stop activation redirect and show error
			wp_die('Sorry, but this plugin requires the WooCommerce to be installed and active. <br><a href="' . admin_url( 'plugins.php' ) . '">&laquo; Return to Plugins</a>');
		}

		$midnight = strtotime("tomorrow midnight");
		
		if ( ! wp_next_scheduled( 'get_all_builders_ac' ) ) {
			wp_schedule_event( time(), 'daily', 'get_all_builders_ac' );
		}
		
		if ( ! wp_next_scheduled( 'get_terms_ini_ac' ) ) {
			wp_schedule_event( time() + 600, 'weekly', 'get_terms_ini_ac' );
		}

		if ( ! wp_next_scheduled( 'get_swatch_images_ac' ) ) {
			wp_schedule_event( time() + 1200, 'weekly', 'get_swatch_images_ac' );
		}
		
		if ( ! wp_next_scheduled( 'get_deleted_vf_products_ac' ) ) {
			wp_schedule_event( time() + 2400, 'daily', 'get_deleted_vf_products_ac' );
		}

		if ( ! wp_next_scheduled( 'new_defaults_if_missing_ac' ) ) {
			wp_schedule_event( time() + 3600, 'daily', 'new_defaults_if_missing_ac' );
		}
		
		if ( ! wp_next_scheduled( 'get_products_ini_ac' ) ) {
			wp_schedule_event( $midnight - 7200, 'daily', 'get_products_ini_ac', array( array(), true ) );
		}

		if ( ! wp_next_scheduled( 'swatch_api_get_call_ac' ) ) {
			wp_schedule_event( $midnight - 7200, 'daily', 'swatch_api_get_call_ac' );
		}

		if ( ! wp_next_scheduled( 'replace_categories_ini_ac' ) ) {
			wp_schedule_event( $midnight - 3600, 'daily', 'replace_categories_ini_ac' );
		}

		if ( ! wp_next_scheduled( 'sync_new_builders_products_ac' ) ) {
			wp_schedule_event( time() + 10000, 'daily', 'sync_new_builders_products_ac' );
		}

		if ( ! wp_next_scheduled( 'delete_exception_skus_ac' ) ) {
			wp_schedule_event( time() + 10000, 'daily', 'delete_exception_skus_ac' );
		}

		if ( ! wp_next_scheduled( 'extra_clean_ini_ac' ) ) {
			wp_schedule_event( $midnight - 10800, 'weekly', 'extra_clean_ini_ac' );
		}

		if ( ! wp_next_scheduled( 'change_order_builder_cats_ac' ) ) {
			wp_schedule_event( time() + 12000, 'fifteendays', 'change_order_builder_cats_ac' );
		}

		if ( ! wp_next_scheduled( 'delete_vf_raw_data_ac' ) ) {
			wp_schedule_event( $midnight - 12000, 'weekly', 'delete_vf_raw_data_ac' );
		}

		wp_schedule_event( $midnight, 'weekly', 'get_products_ini_ac', array( array(), false ) );
			
		$timestamp_help_functions = wp_next_scheduled( 'help_functions' );
		
		wp_unschedule_event( $timestamp_help_functions, 'help_functions');
		
		$timestamp_if_missing_ac = wp_next_scheduled( 'if_missing_atts_ac' );
		
		wp_unschedule_event( $timestamp_if_missing_ac, 'if_missing_atts_ac');

		$timestamp_swatch_images = wp_next_scheduled( 'swatch_images_ac' );
		
		wp_unschedule_event( $timestamp_swatch_images, 'swatch_images_ac');

		$size = array();

		$size = array(
			'width' => '80',
			'height'    => '80',
			'crop'  => 1
		);

		update_option('swatches_image_size', $size);

		$this->_log_version_number();
	} // End install ()

		/**
	 * Deactivation. Runs on deactivation.
	 *
	 * @access  public
	 * @return  void
	 * @since   1.0.0
	 */
	public function deactivate() {
		
		$hooks = array();

		$hooks = array(

			'new_defaults_if_missing_ac',
			'get_all_builders_ac',
			'get_terms_ini_ac',						
			'get_swatch_images_ac',
			'get_deleted_vf_products_ac',
			'get_products_ini_ac',
			'replace_categories_ini_ac',
			'sync_new_builders_products_ac',
			'delete_exception_skus_ac',
			'extra_clean_ini_ac',
			'change_order_builder_cats_ac',
			'swatch_api_get_call_ac'

		);

		foreach ( $hooks as $hook ) {

			wp_clear_scheduled_hook( $hook );

		}


	} // End deactivate ()

	/**
	 * Log the plugin version number.
	 *
	 * @access  public
	 * @return  void
	 * @since   1.0.0
	 */
	private function _log_version_number() { //phpcs:ignore
		update_option( $this->_token . '_version', $this->_version );
	} // End _log_version_number ()

	public function check_version_do_updates() {

		$version = $this->_version;

		$old_version = get_option( $this->_token . '_version');

		if ( $old_version !== $version ) {

			$this->_log_version_number();
		
		}

	}

	function threed_activation() {

		$threed_on = get_option('wpt_vf_show_threed');

		if ( $threed_on === 'on' ) {

			require_once 'threed/threed-public-viewer.php';

			$this->threed = new Threed_Product_Viewer_Public( $this->_token, $this->_version );

			if ( 'yes' !== get_option('wpt_vf_show_threed_activated') ) {

				if ( ! wp_next_scheduled( 'activate_threed_ac' ) ) {

					wp_schedule_event( time(), 'daily', 'activate_threed_ac' );
					
				}

				wp_clear_scheduled_hook( 'deactivate_threed_ac' );

				update_option('wpt_vf_show_threed_activated', 'yes');

				update_option('wpt_vf_show_threed_deactivated', 'no');
			}
			
		} else {

			if ( 'yes' !== get_option('wpt_vf_show_threed_deactivated') ) {

				if ( ! wp_next_scheduled( 'deactivate_threed_ac' ) ) {

					wp_schedule_single_event( time(), 'deactivate_threed_ac' );
					
				}

				wp_clear_scheduled_hook( 'activate_threed_ac' );

				update_option('wpt_vf_show_threed_deactivated', 'yes');

				update_option('wpt_vf_show_threed_activated', 'no');

			}

		}
	}

	function deactivate_threed() {

		$args = array(
			'meta_key' 		=>  'threed_tab_content',
			'post_type' 	=>  'product',
			'post_status'	=>  'publish',
			'fields'		=>  'ids'
		 );
		 
		 $query = get_posts($args);
		
		 foreach ( $query as $prod_id ) {
		
			$get_json = json_decode(get_post_meta($prod_id, 'threed_tab_content', true),true);
		
			$thumbnail_id = $get_json['thumbnail_id'];
		
			if ( $thumbnail_id ) {
		
				$product = wc_get_product($prod_id);
		
				$gallery_images = $product->get_gallery_image_ids();
		
				$key = array_search($thumbnail_id, $gallery_images);
		
				if ( $key ) {
					unset($gallery_images[$key]);
				}
				
				unset($get_json['thumbnail_id']);
		
				$product->set_gallery_image_ids( $gallery_images );
				
				$product->save();
				
				update_post_meta($prod_id, 'threed_tab_content', json_encode($get_json));
		
			}
		 }			
	}

	/**
	 * 
	 * Adding webp to the woocommerce_rest_allowed_image_mime_types filter
	 *
	 * @since 0.0.6
	 *
	 * @param array var default mime types
	 * @return array var new mime type array
	 */

	function more_mimes_to_exts( $mime_to_ext ){
		
		$mime_to_ext['webp'] = 'image/webp';

		return $mime_to_ext;

	}

}
