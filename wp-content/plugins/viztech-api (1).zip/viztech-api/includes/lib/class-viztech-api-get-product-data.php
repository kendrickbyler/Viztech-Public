<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Step 1. */

/* These commands are used to retrieve the data from Viztech Furniture */

class viztech_api_get_product_data {

    function __construct() {
        $this->loadGetProductDataActions();
    }

    private function loadGetProductDataActions() {
        
        // initial hook to get all data
        add_action('get_products_ini_ac', array($this, 'get_products_ini'), 10, 2);
        
        add_action('check_amounts_ac', array($this, 'check_amounts'), 10, 3);
        add_action('get_product_data_ac', array($this, 'get_product_data'), 10, 5);       
        add_action('get_variation_data_ini_ac', array($this, 'get_variation_data_ini'), 10, 4);
        add_action('get_variation_data_ac', array($this, 'get_variation_data'), 10, 4);
		add_action('get_swatch_images_ac', array($this, 'get_swatch_images'));
        add_action('sync_new_builders_products_ac', array($this, 'sync_new_builders_products'));
        add_action('admin_post_nopriv_product_create_updated', array($this, 'process_data_form_product'), 10);

        add_action('swatch_api_get_call_ac', array($this, 'swatch_api_get_call'));

        
    }


    /**
     * 
     * Initial function to get all product data from database. Accepts either an array of certain builders, or, if the arg is empty it gets all the data from the database. It also resets the previous data to make sure the data we use is fresh.
     * 
     * @link https://actionscheduler.org/ I'm using the WooCommerce Action Scheduler for most of my cron jobs. 
     * 
     * @since 1.0.0
     *
     * @param array var array of selected builders
     * @return string Text displayed at add to cart.
     */

    function get_products_ini( $new_builders = array(), $recents = false ) {

        // bail if cron jobs full
        $empty = $this->check_if_cron_empty();
        if ( false === $empty ) {
            return;
            
        }

        // getting an array with of all the builders
        $builders = $this->get_builders();
    
        // if the arg is empty that is passed through the function then get all the builders
        $builders = ( empty($new_builders) ) ? $builders : $new_builders;

        // check the global options, if the site wants only design center products or everything
        $products_syncing_options = (string) get_option('wpt_vf_design_center_products');

        // resetting category data weekly ( this data can get stale, need to refresh, like weekly )
        if ( false === $recents && empty($new_builders) ) {
            update_option('all_cats_raw', '', 'no');
            update_option('vf_cats', '', 'no');
        }


        // start the loop through all the selected builders
		foreach ( $builders as $builder ) {

            // resetting data - need to do the below, when we do the weekly checking
            if ( false === $recents && empty($new_builders) ) {
                $index_raw = 'vf_products_'.$builder;
                $index_clean = 'products_'.$builder;
                update_option( $index_raw, '', 'no' );
                update_option( $index_clean, '', 'no' );
            }
            
            // checking to see whether or not to sync all products
            if ( empty( $products_syncing_options ) || $products_syncing_options === 'all_products' ) {

                // if all products selected, then go get all the product data
                as_enqueue_async_action( 'check_amounts_ac', array( $builder, 'simple', $recents ) );
                as_enqueue_async_action( 'check_amounts_ac', array( $builder, 'variable', $recents ) );

            // if retailers only one design center products only get design center products
            } elseif ( $products_syncing_options === 'design_center_only' ) {
              
                as_enqueue_async_action( 'check_amounts_ac', array( $builder, 'variable', $recents ) );

            // not sure if this will happen, but, if someone only wants the non design center products
            } elseif ( $products_syncing_options === 'non_design_center_products' ) {

                as_enqueue_async_action( 'check_amounts_ac', array( $builder, 'simple', $recents ) );

            }
            
		}
    }

    /**
     * This function checks to see how many products exist in each of the builder categories in the product database.
     * 
     * By default, WooCommerce has a limit of returning 100 products at a time. In order to get all the data that we need, we need to figure out how many "pages" of data of products there are in each builder category we are getting.
     *
     * @since 0.0.1
     *
     * @param string $category or builder to get
     * @return string $type of product, either simple or variable (for design center)
     */
    
    function check_amounts( $category, $type, $recents ) {

        /* For simple products, we can get 50 products at a time pretty easily. However, for variable products because those products are so much bigger, I am getting them 5 at a time. I used to have it at 10, but even then I had memory issues. */
        $per_page = ( $type === 'simple' ) ? 50 : 5;

        /* Here I'm getting ready to do my first API call, this is the args. If it's a simple product, do 100 products per_page, but, if it's a variable product, only 10. */
        $data = array();
        $data = array(
            'category'  => (string) $category,
            'status'    => 'publish',
            'type'      => (string) $type,
            'per_page'  => (int) $per_page,
            'page'      => 1,
        );

        if ( true === $recents ) {

            $twodaysago = gmdate('Y-m-d\TH:i:s', strtotime("-7 days") );

            $data['dates_are_gmt'] = true;
            $data['modified_after'] = $twodaysago;


        }


        // initiating the Woo Client so I can grab 1 page of data per builder
        $client_api = new Woo_Client_API();
        $woo = $client_api->woo_client();
        $product_data = json_encode($woo->get( 'products', $data ));

        // bail if empty (turn json into array first)
        $product_data_arr = array();
        $product_data_arr = json_decode($product_data,true);

        if ( empty($product_data_arr) ) {
            return;
        }

        // in the http response, more specficially, in the headers there's some important data that I need for futher data calls
        $lastRequest = $woo->http->getResponse();
        $headers = $lastRequest->getHeaders();

        /* sometimes the data comes through in upper or lower case, just to make sure everything is uniform, I'm converting everything to lower case, just in case */
        $headers = array_change_key_case($headers,CASE_LOWER);
        
        /* This is the most important piece of information. We need to find out how many pages of data there are, per builder category. Example would be, if there are 500 products in Artisan Chair category, and the per page amount is 50, then 500 / 50 = 10. So, it would take 10 pages to get all the data. */
        $total_pages = (int) $headers['x-wp-totalpages'];

        /* If total pages is more than one, then do a for loop for the amount of pages, if there is only one page, then just go ahead and store the data. */
        if ( $total_pages > 1 ) {
            
            // for each of the pages, initiate the function to get all the product data for the builder category
            for ($i = 1; $i <= $total_pages; ) {

                /* args to get all of the data, $category is the builder, $type is either "variable" or "simple" product, $i is the page, and $per_page is the amount of products to get per page */
                $hook = 'get_product_data_ac';
                $product_data_multiple_pages = array();
                $product_data_multiple_pages = array( $category, $type, $i, $per_page, $recents );

                // In order to not create duplicate cron jobs, I'm checking to see if it exists first. There can be duplicate "hooks", but, not duplicate "hooks" and "args". 
                $if_has_scheduled = as_has_scheduled_action( $hook, $product_data_multiple_pages );
                if ( false === $if_has_scheduled ) {
                    as_enqueue_async_action( $hook, $product_data_multiple_pages );
                }
            
                $i++;
            }

        } else {

            $this->merge_product_data( $product_data, $category );

        }

    }

    /**
     * 
     * Getting the raw data from the product database based on the previous function, that checked to see how many products were per category
     *
     * @since 1.0.0
     *
     * @param string $builder category
     * @param string $type of product, "simple" or "variable"
     * @param int $page
     * @param int $per_page
     */
    
    function get_product_data( $builder, $type, $page, $per_page, $recents = false ) {

        // args to get the data from the database
        $data = array(); 
        $data = array(
            'category'  => (string) $builder,
            'status'    => 'publish',
            'type'      => (string) $type,
            'per_page'  => (int) $per_page,
            'page'      => (int) $page,
        );

        if ( true === $recents ) {

            $twodaysago = gmdate('Y-m-d\TH:i:s', strtotime("-7 days") );

            $data['dates_are_gmt'] = true;
            $data['modified_after'] = $twodaysago;

        } 

         // initiating the Woo Client
        $client_api = new Woo_Client_API();
        $woo = $client_api->woo_client();
        
        // raw data from the product database, and encode it in json
        $product_data = json_encode($woo->get( 'products', $data ));

        // take the new data and merge it with the old data
        $this->merge_product_data( $product_data, $builder );

    }

    /**
     * 
     * Takes the raw data that come from the product database, and merges it with the current data stored in the local database.
     *
     * @since 0.0.1
     *
     * @param array $product_data
     * @return string $builder
     */

    function merge_product_data( $product_data, $builder ) {

        $new_product_data = array();

        $new_product_data = json_decode($product_data,true);

        $formatted_data = array();

        foreach ( $new_product_data as $new_product ) {

            $id = $new_product['id'];

            $new_product = $this->remove_data($new_product);

            $formatted_data[$id] = $new_product;

        }

        $products_old = array();

        $index = 'vf_products_'.$builder;

        $products_old = json_decode(get_option($index),true);

        $products_old = ( ! empty($products_old) ) ? $products_old : array(); 
      
        $all = $formatted_data + $products_old;

        update_option($index, json_encode($all, JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS), 'no' );
        
        $hook = 'clean_data_ac';

        $args = array();

        $args = array( $index, $builder );

		$if_has_scheduled = as_has_scheduled_action( $hook, $args );

		if ( false === $if_has_scheduled ) {
			as_schedule_single_action(time() + 100, $hook, $args );
		}

    }


    /**
     * 
     * After the product gets created, this function gets triggered on all variable products.  
     *
     * @since 1.0.0
     *
     * @param int $id local product id
     * @param int $vf_id product database id
     * @param int $builder id
     * @param int number of pages of variations, I figure the amount of pages by taking the total number of varations and divide it by 10 (100 / 10 = 10 pages)
     */


    function get_variation_data_ini($id, $vf_id, $builder, $pages) {

        for ($i = 1; $i <= $pages; ) {
            // code to repeat here
             
            $hook = 'get_variation_data_ac';

            $args = array();

            $args = array($id, $vf_id, $builder, $i);

            $if_has_scheduled = as_has_scheduled_action( $hook, $args );

            if ( false === $if_has_scheduled ) {

                as_enqueue_async_action( $hook, $args );

            }
        
            $i++;       
        }

    }

    function get_variation_data( $id, $vf_id, $builder, $page ) {

        $format_products = new viztech_api_format_products();

        $this_id = absint($id);

        $viz_id = absint($vf_id);

        $this_builder = absint($builder);

        $client_api = new Woo_Client_API();
        
        $woo = $client_api->woo_client();

        $data = array(
            'per_page'  => 10,
            'page'      => (int) $page
        );

        $variation_data = json_encode($woo->get( 'products/'.$viz_id.'/variations', $data));        

        if ( ! empty($variation_data) ) {
            
            $format_products->clean_variation_data(json_decode($variation_data,true), $this_id, $this_builder, $page);

        }
        
    }

    function get_swatch_images() {

        $all_swatches = json_decode( get_option('swatch_images_data'),true );

        $formatting_prods = new viztech_api_format_products();

		$attribute_taxonomies = wc_get_attribute_taxonomies();

		$taxonomy_terms = array();
		
		foreach ( $attribute_taxonomies as $tax ) {
			
			$taxonomy_terms[] = get_terms( wc_attribute_taxonomy_name($tax->attribute_name), 'orderby=name&hide_empty=0' );

		}
				
		foreach ( $taxonomy_terms as $terms  ) {
			foreach ( $terms as $term ) {
                
                $term_name = $term->name;

                $term_name = str_replace(' ', '-', strtolower($term_name));

                $term_name = $term->taxonomy . '-' . $term_name;

                $jsonTermDESC = json_decode($all_swatches[$term_name],true);
		
				if ( ! empty($jsonTermDESC['swatch_id']) ) {
		
						$vf_swatch = (int) get_term_meta($term->term_id, $term->taxonomy . '_swatches_id_photo_vf', true );
		
					if ( $vf_swatch !== $jsonTermDESC['swatch_id'] ) {
							
						$link = $jsonTermDESC['image_link'];
			
						$attach_id = $formatting_prods->get_attachment_id_from_url_viztech( $link );

                        update_term_meta($term->term_id, $term->taxonomy . '_swatches_id_photo', (int) $attach_id );
                        
                        update_term_meta($term->term_id, $term->taxonomy . '_swatches_id_type', 'photo' );
                        update_term_meta($term->term_id, $term->taxonomy . '_swatches_id_color', '#FFFFFF' );
                        update_term_meta($term->term_id, $term->taxonomy . '_swatches_id_photo_vf', (int) $jsonTermDESC['swatch_id'] );
							
					} 	
				} elseif ( ! empty($jsonTermDESC['swatch_color']) ) {

                    $current_color = get_term_meta($term->term_id, $term->taxonomy . '_swatches_id_color', true );

                    if ( $current_color !== $jsonTermDESC['swatch_color'] ) {
                        update_term_meta($term->term_id, $term->taxonomy . '_swatches_id_type', 'color' );
                        update_term_meta($term->term_id, $term->taxonomy . '_swatches_id_color', $jsonTermDESC['swatch_color'] );
                    }

                }

                
			}
		}
	}

    function get_builders() {

        $all_selected_builders = array();

        $all_selected_builders = get_option('wpt_vf_builders');

        $all_builders_option = get_option('wpt_vf_sync_everything');

        $all_builders = array();

        $all_builders = json_decode(get_option('builder_categories'));

        $builders = array();

        $builders = 'on' === $all_builders_option ? wp_list_pluck( $all_builders, 'id' ) : $all_selected_builders;

        return $builders;

    }

    function sync_new_builders_products() {

        $builders = $this->get_builders();

        foreach ( $builders as $sel_builder ) {

            $index = 'products_'.$sel_builder;
        
            $products = json_decode( get_option( $index ),true );    
        
            $products = ! empty($products) ? $products : array();
        
            $prods[] = count( $products );
                
            if ( count($products) === 0 ) {
                
                $this->get_products_ini( array( $sel_builder ) );
        
                as_schedule_single_action( time() + 10800, 'replace_cats_atts_ac', array( $sel_builder ) );
        
            }
        
        }

    }

    /**
     * 
     * Process webhook data from the product database. This code only runs on the kiosk and the portal. Basically any site that has webhooks set up on the product database.
     * 
     * @link https://bhanusingh.in/creating-a-custom-webhook-in-wordpress-to-get-data-from-third-part-services
     * @since 0.0.5
     * 
     */

    function process_data_form_product() {

        $request = file_get_contents('php://input'); // get data from webhoook
        
        $product = array();
    
        $product = json_decode($request, true);
    
        // getting an array with of all the builders
        $builders = $this->get_builders();
    
        if ( $product['type'] !== 'variation' && $product['status'] === 'publish' ) {
    
            $cats = $product['categories'];
    
            $json_product = json_encode($product);

            foreach ( $cats as $cat ) {
                if ( in_array( $cat['id'], $builders ) ) {
        
                    $old_data = json_decode( get_option('vf_products_' . $cat['id'] ), true );
                    
                    $old_data = ! empty($old_data) ? $old_data : array();

                    $new_product = array();

                    $new_product[$product['id']] = $product;

                    $all_data = array();

                    $all_data = $new_product + $old_data;
                    
                    update_option('vf_products_'.$cat['id'], json_encode($all_data, JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS), 'no');
                    
                    $hook = 'clean_single_product_ac';

                    $args = array($product['id'], $cat['id'] );

                    $if_has_scheduled = as_has_scheduled_action( $hook, $args );

                    if ( false === $if_has_scheduled ) {

                        as_enqueue_async_action( $hook, $args );                    

                    }

                }
            }
    
        }
    
    }

    /**
     * 
     * Check if crons are empty
     *
     * @since 0.0.5
     *
     * @return bool if cron empty return true
     */

    function check_if_cron_empty() {

        $empty = true;

        $creating_variations = as_has_scheduled_action('create_variations_ac');

        $creating_products = as_has_scheduled_action('create_products_ac');

        $get_variation = as_has_scheduled_action('get_variation_data_ac');

        if ( true === $creating_variations || true === $creating_products || true === $get_variation ) {

            $empty = false;

        }

        return $empty;

    }

    function remove_data( $new_product ) {

        $remove_data = array();

        $remove_us = array( 'total_sales', 'virtual', 'downloadable', 'downloads', 'download_limit', 'download_expiry', 'external_url', 'button_text', 'manage_stock', 'stock_quantity', 'backorders', 'backorders_allowed', 'backordered', 'low_stock_amount', 'sold_individually', 'weight', 'dimensions', 'shipping_required', 'shipping_taxable', 'shipping_class', 'shipping_class_id', 'reviews_allowed', 'average_rating', 'rating_count', 'upsell_ids', 'cross_sell_ids', 'purchase_note', 'grouped_products', '_links', 'sale_price', 'date_on_sale_from', 'date_on_sale_from_gmt', 'date_on_sale_to', 'date_on_sale_to_gmt', 'on_sale' );

        foreach ( $remove_us as $rem_us ) {
            unset($new_product[$rem_us]);
        }

        return $new_product;

    }

    /**
     * 
     * Get swatch data from database
     *
     * @since 0.0.8
     *
     */
    
     function swatch_api_get_call(){

        $site = esc_url_raw(get_option('wpt_url_site_api'));

        $site = ! empty($site) ? $site : 'https://products.viztechfurniture.com/';

        $tag_response = wp_remote_get( $site . 'wp-json/wp/v2/tags?per_page=100');
    
        if(is_wp_error($tag_response)){
            die();
        }
    
        $tag_body = wp_remote_retrieve_body($tag_response);
    
        $tag_data = json_decode($tag_body, true);
    
        foreach($tag_data as $tag){
    
            $swatch_response = wp_remote_get( $site . 'wp-json/wp/v2/swatches?_embed&per_page=100&tags=' . $tag['id']);
    
            if(is_wp_error($swatch_response)){
                break;
            }
    
            $swatch_body = wp_remote_retrieve_body($swatch_response);
    
            $swatch_data = json_decode($swatch_body, true);
    
            update_option('vf-swatch-' . $tag['slug'], $swatch_data, 'no');
    
            if(count($swatch_data === 100)){
    
                $page = 2;
    
                $second_data = '';
    
                while(empty($second_data) || count($second_data) === 100){
    
                    $second_response = wp_remote_get( $site . 'wp-json/wp/v2/swatches?_embed&per_page=100&tags=' . $tag['id'] . '&page=' . $page);
    
                    $second_body = wp_remote_retrieve_body($second_response);
    
                    $second_data = json_decode($second_body, true);
    
                    if(empty($second_data)){
                        break;
                    }
    
                    $existing_data = get_option('vf-swatch-' . $tag['slug']);
    
                    $new_data = array_merge($existing_data, $second_data);
    
                    update_option('vf-swatch-' . $tag['slug'], $new_data, 'no');
    
                    $page++;
    
                }
            }  
        }
    
    }
}

new viztech_api_get_product_data();

?>