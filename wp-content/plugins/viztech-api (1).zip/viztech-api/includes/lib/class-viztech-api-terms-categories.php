<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Step 3. */

/* These commands are used to extract and sync the terms such as categories as well as the Global Attribute data */

class viztech_api_terms_categories {

    function __construct() {
        $this->loadTermsCategories();
    }

    private function loadTermsCategories() {
        add_action('extract_terms', array($this, 'extract_prod_terms'), 10, 1);
        add_action('sync_cats', array($this, 'sync_categories'), 10, 1);
        add_action('get_terms_ini_ac', array($this, 'get_terms_ini'));        
        add_action('get_terms_ac', array($this, 'get_terms_vf'), 10, 2);        
        add_action('replace_cats_atts_ac', array($this, 'replace_cats_atts'), 10, 2); 
        add_action('replace_categories_ini_ac', array($this, 'replace_categories_ini'), 10, 1 ); 

        add_action('change_order_builder_cats_ac', array($this, 'change_order_builder_cats') ); 
        add_action('replace_cats_atts_single_product_ac', array($this, 'replace_cats_atts_single_product'), 10, 2 );
        
        add_action('clear_cats_sync_ac', array($this, 'clear_cats_sync') );
    }

    function extract_prod_terms($category) {
        
        $all_products = json_decode(get_option( 'products_'.$category ),true);

        $cats = array();

        $atts = array();
        
        $existing_cats = json_decode(get_option('vf_cats'),true);

        $existing_cats = ! empty($existing_cats) ? $existing_cats : array();

        foreach ( $all_products as $product ) {
      
            if ( isset( $product['categories'] ) && is_array( $product['categories'] )  ) {

                foreach ( $product['categories'] as $cat ) {
                    
                    $id = $cat['id'];
                    
                    if ( ! array_key_exists($id, $existing_cats ) ) {
                        $cats[$id] = $cat['name'];
                    }
                }

            }

            foreach ( $product['attributes'] as $attribute ) {
                
                $id = $attribute['id'];

                // only if global atttribute, if local text attribute the id will be 0 and we want to ignore them here
                if ( 0 !== $id ) {

                    $existing_id = wc_attribute_taxonomy_id_by_name($attribute['name']);

                    if ( empty($existing_id) ) {
                        $atts[$id] = wc_sanitize_taxonomy_name($attribute['name']);   
                    }
                }                                   
            }

        }

            
        if ( ! empty($atts) ) {
            $this->do_atts($atts);
        }
    
        if ( ! empty($cats) ) {
            $this->get_cat_data($cats);
        }

    }

    
    function extract_terms_product($product_id, $category) {

        $all_products = json_decode(get_option( 'products_'.$category ),true);

        $product = $all_products[$product_id];

        if ( empty($product) ) {
            return;
        }

        $cats = array();

        $atts = array();
        
        $existing_cats = json_decode(get_option('vf_cats'),true);

        $existing_cats = ! empty($existing_cats) ? $existing_cats : array();

        if ( isset( $product['categories'] ) && is_array( $product['categories'] )  ) {

            foreach ( $product['categories'] as $cat ) {
                
                $id = $cat['id'];
                
                if ( ! array_key_exists($id, $existing_cats ) ) {
                    $cats[$id] = $cat['name'];
                }
            }

        }

        foreach ( $product['attributes'] as $attribute ) {
            
            $id = $attribute['id'];

            // only if global atttribute, if local text attribute the id will be 0 and we want to ignore them here
            if ( 0 !== $id ) {

                $existing_id = wc_attribute_taxonomy_id_by_name($attribute['name']);

                if ( empty($existing_id) ) {
                    $atts[$id] = wc_sanitize_taxonomy_name($attribute['name']);   
                }
            }                                   
        }


        if ( ! empty($atts) ) {
            $this->do_atts($atts);
        }
    
        if ( ! empty($cats) ) {
            $this->get_cat_data($cats);
        }

        $hook = 'replace_cats_atts_single_product_ac';

        $args = array($product_id, $category);

        $if_has_scheduled = as_has_scheduled_action( $hook, $args );

        if ( false === $if_has_scheduled ) {

            as_schedule_single_action( time() + 300, $hook, $args );

        }
       
    }


    function do_atts($atts) {
        
        $client_api = new Woo_Client_API();

        $woo = $client_api->woo_client();
        
        global $wp_rest_server;
        
        $response = array();

        foreach ( $atts as $key => $att ) {

            $id = wc_attribute_taxonomy_id_by_name($att);

            $att_slug = 'pa_' . $att;

            if ( empty($id) ) {
             
                $new_att = array();

                $route = 'products/attributes/'.$key;

                $new_att = (array) $woo->get($route);

                unset($new_att['id']);

                unset($new_att['slug']);

                $request = new WP_REST_Request( 'POST' );
                $request->set_body_params( $new_att );
                $att_controller = new WC_REST_Product_Attributes_Controller; 
                $response = $att_controller->create_item( $request );
                
                $new_att_slug = ( is_wp_error($response) ) ?  $att_slug : $response->data['slug'];

            }

        }

    }

    function get_terms_ini() {

        $client_api = new Woo_Client_API();
        
        $woo = $client_api->woo_client();

        $route = 'products/attributes/';

        $atts = json_encode( $woo->get( $route ) );

        $atts = json_decode($atts,true);

        foreach ( $atts as $att ) {
                
            $hook = 'get_terms_ac';

            $args = array( $att['id'], $att['name'] );

            $if_has_scheduled = as_has_scheduled_action( $hook, $args );

            if ( false === $if_has_scheduled ) {
                as_enqueue_async_action( $hook, $args );
            }

        }

    }


    function get_terms_vf( $key, $name ) {
        
        $client_api = new Woo_Client_API();
        
        $route = 'products/attributes/'.$key.'/terms';

        $terms = json_decode($client_api->woo_getter($route),true);
    
        $new_data = array();

        $att_name = 'pa_' . str_replace(' ', '-', strtolower($name));

        foreach ( $terms as $term ) {

            $id = $term['name'];
            
            $id = str_replace(' ', '-', strtolower($id));

            $id = $att_name . '-' . $id;

            if ( ! empty( $term['description'] ) ) {

                $new_data[$id] = $term['description'];

            }

        }

        $old_swatches = json_decode( get_option('swatch_images_data'),true );

        $old_swatches = ! empty( $old_swatches ) ? $old_swatches : array();

        $all_swatches = array();

        $all_swatches = $new_data + $old_swatches;

        update_option('swatch_images_data', json_encode($all_swatches, JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS), 'no');
            
    } 


    function get_cat_data($cats) {

        $client_api = new Woo_Client_API();
      
        $cat_ids = array();
      
        foreach ( $cats as $key => $cat ) {
      
          $cat_ids[] = $key; 
      
        }
      
        $cat_ids_string = implode(",", $cat_ids);
      
        $data = array();
              
        $data = array('include' => $cat_ids_string);
        
        $all = json_decode($client_api->woo_getter( 'products/categories', $data ),true);
      
        $all_change = array();
      
        foreach ( $all as $ct ) {
          $ct_id = $ct['id'];
          $all_change[$ct_id] = $ct;
        } 
        
        $old_cats_raw = json_decode(get_option('all_cats_raw'),true);

        $old_cats_raw = ( ! empty($old_cats_raw) ) ? $old_cats_raw : array();

        $all_cats_raw = array();

        $all_cats_raw = $all_change + $old_cats_raw;

        update_option('all_cats_raw', json_encode($all_cats_raw, JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS), 'no');
        
        as_enqueue_async_action( 'sync_cats' );
        
      }
      

    function sync_categories() {

        $client_api = new Woo_Client_API();
 
        $cats_raw = json_decode(get_option('all_cats_raw'),true);
      
        $terms = array();
      
        $terms = ( empty(get_option('vf_cats') ) ) ? array() : json_decode( get_option('vf_cats'), true );

        $add_to_raw = array();
      
        $new_terms = array();
        
        foreach ( $cats_raw as $key => $cats ) {

            // needs more than just if array key exists, need to check if actual cat exists

            $term_exists = '';
            
            $term_exists = get_term_by('term_id', $terms[$key], 'product_cat');

            if ( empty($term_exists) ) {
                
                $get_ancestors_arr = array();
      
                $get_ancestors_arr = ( isset($cats['ancestors']) ) ? $cats['ancestors'] : array() ;
              
                if ( empty($get_ancestors_arr) ) {
        
                // don't like the way of creating terms, need helper function that uses api methods to create the term
                // something like $woocommerce->put($endpoint, $data)
                // would need to do something different then the getter to make so it's the local site
        
                $new_terms[$key] = $cats;

                } else { 
        
                    $new_terms[$key] = $cats;

                    $get_ancestors_arr = array_reverse($get_ancestors_arr);
        
                    $parent_id = 0;
        
                    foreach ($get_ancestors_arr as $term_ancestor) {
        
                        if ( ! array_key_exists($term_ancestor, $terms) ) {
                            
                            $data = array();
                        
                            $data = array('include' => $term_ancestor);
                            
                            $all = json_decode($client_api->woo_getter( 'products/categories', $data ),true);    
                    
                            // needs a way to either make so this category data gets added to 
                            // 'all_cats_raw', needs helper function

                            foreach ($all as $new_cat) {
                                
                                $id = $new_cat['id'];

                                $add_to_raw[$id] = $new_cat;
                            }         
                            
                            $all_cats = array();

                            $all_cats = $add_to_raw + $cats_raw;

                            update_option('all_cats_raw', json_encode($all_cats, JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS), 'no');

                            as_enqueue_async_action( 'sync_cats' );

                        } else {
            
                            $new_terms[$key] = $cats;
                        }
                        
                    }
                }
            }
        }

        if ( ! empty($new_terms) ) {

            as_enqueue_async_action( 'sync_cats' );
         
            $this->sync_category($new_terms, $terms);

        }
        
    }
      
    function sync_category($new_terms, $terms) {

        $new_data = array();

        foreach ( $new_terms as $term ) {
           
            $id = $term['id'];

            unset($term['id']);

            unset($term['slug']);

            unset($term['image']['id']);

            $new_data[$id] = $term;

        }

        global $wp_rest_server;
        
        $response = array();

        $new_term_ids = array();

        foreach ( $new_data as $key => $new_cat ) {

            $parent = $new_cat['parent'];

            if ( $parent === 0 ) {

                // need to make below code into function

                $request = new WP_REST_Request( 'POST' );
                $request->set_body_params( $new_cat );
                $cat_controller = new WC_REST_Product_Categories_Controller; 
                $response = $cat_controller->create_item( $request );

                $term_id = ( is_wp_error($response) ) ? $response->error_data['term_exists']['resource_id'] : $response->data['id'];
                
                if ( $term_id ) {
                 
                    update_term_meta($term_id, 'vf_cat_id', (int) $key );

                    $new_term_ids[$key] = $term_id;
    
                    do_action('new_term_created', $term_id);

                }

            } else {

                $new_parent = 0;

                $new_parent = ( ! empty($terms[$parent] ) ) ? $terms[$parent] : 0 ;

                if ( $new_parent !== 0 ) {
                    
                    $new_cat['parent'] = $new_parent;

                    // // need to make below code into function
                    $request = new WP_REST_Request( 'POST' );
                    $request->set_body_params( $new_cat );
                    $cat_controller = new WC_REST_Product_Categories_Controller; 
                    $response = $cat_controller->create_item( $request );

                    $term_id = ( is_wp_error($response) ) ? $response->error_data['term_exists']['resource_id'] : $response->data['id'];
                   
                    if ( $term_id ) {

                        update_term_meta($term_id, 'vf_cat_id', (int) $key );
                    
                        $new_term_ids[$key] = $term_id;
    
                        do_action('new_term_created', $term_id);

                    }

                } else {
                    
                    // i think i need to do something here, not sure what yet :--( 

                } 
            }
        }

        $all_terms = array();

        $all_terms = $new_term_ids + $terms;
    
        update_option('vf_cats', json_encode($all_terms, JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS), 'no');

        /* Clear sync cats cron jobs in 20 minutes to stop infinite loops from happening  */

        if ( ! wp_next_scheduled( 'clear_cats_sync_ac' ) ) {
            wp_schedule_single_event(time() + 3600, 'clear_cats_sync_ac');
            wp_schedule_single_event(time() + 7200, 'clear_cats_sync_ac');
            wp_schedule_single_event(time() + 10800, 'clear_cats_sync_ac');
        }

    }  
    
    function clear_cats_sync() {

        $hook = 'sync_cats';

        $if_has_scheduled = as_has_scheduled_action( $hook );

        if ( true === $if_has_scheduled ) {
            as_unschedule_all_actions( 'sync_cats' );
        } else {
            wp_clear_scheduled_hook('clear_cats_sync_ac');
        }

    }

    function replace_categories_ini( $new_builders = array() ) {

        $getting_prods = new viztech_api_get_product_data();

        //bail if cron not empty
        $empty = $getting_prods->check_if_cron_empty();
        if ( false === $empty ) {
            return;
        }

		$builders = $getting_prods->get_builders();

        $builders = ( empty($new_builders) ) ? $builders : $new_builders;

		foreach ( $builders as $builder ) {

            $hook = 'replace_cats_atts_ac';

            $args = array( (int) $builder );

            $if_has_scheduled = as_has_scheduled_action( $hook, $args );

            if ( false === $if_has_scheduled ) {
                as_enqueue_async_action( $hook, $args );
            }
 
        }

    }

    function replace_cats_atts( $builder, $force_all = false ) {

        $index = 'products_'.$builder;

        $builder_products = array();

        $builder_products = json_decode(get_option($index),true);

        $new_products = array();

        foreach ( $builder_products as $key => $product ) {

            if ( $product['ready'] !== 'yes' ) {

                if ( isset( $product['categories'] ) ) {
                    $product = $this->replace_cats($product);
                }
                
                
                if ( $product['type'] === 'variable' ) {
                    $product = $this->replace_atts($product);
                }

                $product['ready'] = 'yes';

            }


            $new_products[$key] = $product;
                        
            if ( true === $force_all ) {

                $hook = 'create_products_ac';

                $args = array( $index, $key );
        
                $if_has_scheduled = as_has_scheduled_action( $hook, $args );
        
                if ( false === $if_has_scheduled && $product['ready'] === 'yes' ) {

                    as_schedule_single_action( time() + 100, $hook, $args );

                }

            } else {

                $if_sync = $this->check_product($product);

                if ( false !== $if_sync ) {

                    $hook = 'create_products_ac';

                    $args = array( $index, $key );
            
                    $if_has_scheduled = as_has_scheduled_action( $hook, $args );
            
                    if ( false === $if_has_scheduled && $product['ready'] === 'yes' ) {
    
                        as_schedule_single_action( time() + 100, $hook, $args );
    
                    }
    
                }
            
            }

        }
    
        update_option('products_'.$builder, json_encode($new_products, JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS), 'no' );

    }

    function check_product( $product ) {

        $formatting_prods = new viztech_api_format_products();

		$existing_product_id = $formatting_prods->get_existing_product( $product );

        $sync = false;

        if ( empty($existing_product_id) ) {

            $sync = true;

        } else {

            $ex_product = wc_get_product($existing_product_id);

            $current_product_date = $ex_product->get_date_created();

		    $current_product_date = date("Ymd:H:i:s", strtotime($current_product_date));

            $new_product_date = $product['date_modified_gmt'];

            $new_product_date = date("Ymd:H:i:s", strtotime($new_product_date));    
            
            if ( $current_product_date !== $new_product_date ) {

                $sync = true;

            } else {
     
                $type = $ex_product->get_type();

                if ( 'variable' === $type ) {
    
                    $kids = $ex_product->get_children();

                    $ex_kids_count = count($kids);

                    $new_kids_count = count($product['variations']);

                    if ( empty( $kids ) || $ex_kids_count !== $new_kids_count ) {
                        $sync = true;
                    }   
    
                }
                
            }

        }

        return $sync;

    }


    function replace_cats_atts_single_product($product_id, $category) {

        $all_products = json_decode(get_option( 'products_'.$category ),true);

        $product = $all_products[$product_id];

        if ( empty($product) ) {
            return;
        }

        if ( $product['ready'] !== 'yes' ) {

            if ( isset( $product['categories'] ) ) {
                $product = $this->replace_cats($product);
            }

            if ( $product['type'] === 'variable' ) {
                $product = $this->replace_atts($product);
            }

            $product['ready'] = 'yes';

        }

        $all_products[$product_id] = $product;

        update_option('products_'.$category, json_encode($all_products, JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS), 'no' );

        $hook = 'create_products_ac';

        $args = array( 'products_'.$category, $product_id );

        $if_has_scheduled = as_has_scheduled_action( $hook, $args );

        if ( false === $if_has_scheduled && $product['ready'] === 'yes' ) {
            as_schedule_single_action( time() + 100, $hook, $args );
        }

    }
    
    function replace_cats($product) {

        $vf_cats = array();

        $vf_cats = json_decode(get_option('vf_cats'),true);
        
        $cats = array();
        
        $missing_keys = array();
        
        foreach ( $product['categories'] as $key => $cat ) {
        
            $cat_id = $cat['id'];
        
            $new_cat = ( ! empty($vf_cats[$cat_id] ) ) ? $vf_cats[$cat_id] : 0;
        
            if ( $new_cat !== 0 ) {
        
                $cat['id'] = $new_cat;
        
                $cats[] = $cat;
        
            } else {
                $missing_keys = true;
            } 
        
        }
        
        if ( true !== $missing_keys ) {
        
            $product['categories'] = $cats;
        
        } else {
            unset($product['categories']);
        }
        
        return $product;
    }

    function replace_atts($product) {

        $amt = count($product['variations']);

        $pages = ( $amt >= 10 ) ? ceil($amt / 10 ) : 1;

        $product['pages'] = $pages;

        $atts = array();

        foreach ( $product['attributes'] as $att_key => $att ) {

            $id = wc_attribute_taxonomy_id_by_name($att['name']);

            $new_att = ( ! empty($id) ) ? $id : false;

            if ( $new_att !== false ) {

                $att['vf_att_id'] = $att['id'];

                $att['id'] = $new_att;

                $atts[] = $att;

            } elseif ( 0 === $att_key ) { 
                
                $att['id'] = $att_key;

                $atts[] = $att;

            } else {
    
                unset($att['id']);

                $atts[] = $att;
    
            } 
            
         }

         $def_atts = array();

         foreach ( $product['default_attributes'] as $def_att ) {

            $def_id = wc_attribute_taxonomy_id_by_name($def_att['name']);

            $new_def_att = ( ! empty($def_id) ) ? $def_id : 0;

            if ( $new_def_att !== 0 ) {

                $def_att['vf_att_id'] = $def_att['id'];

                $def_att['id'] = $new_def_att;

                $def_atts[] = $def_att;

            } 
            
         }

         if ( ! empty($atts) ) {

            $product['attributes'] = $atts;
        
            $product['default_attributes'] = $def_atts;

        } else {
           
            unset($product['attributes']);

            unset($product['default_attributes']);

        }

        return $product;

    }


    /**
     * 
     * Changes the order of all the builder categories, A-Z
     * Runs as a daily cron job.
     * @since 0.0.4
     *
     */

    function change_order_builder_cats() {

        $builder = get_term_by('slug', 'builders', 'product_cat');

        $builder_id = $builder->term_id;

        $builder_order = get_term_meta($builder_id, 'order', true);

        $args = array(

            'child_of'  => $builder_id,
            'taxonomy' => 'product_cat',

        );

        $cats = get_categories($args);

        if ( empty($cats) ) {
            return;
        }

        $cats_resort = array_column($cats, 'name');

        array_multisort($cats_resort, SORT_ASC, $cats);

        $new_order = $builder_order + 1;

        foreach ( $cats as $cat ) {

            update_term_meta( $cat->term_id, 'order', $new_order );
            
            $new_order++;

        }

    }

}

new viztech_api_terms_categories();


?>