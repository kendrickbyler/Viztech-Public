<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* These commands are used to delete products, either from viztech, or, everything if you want to have a clean slate. */


class viztech_api_delete_products {

    function __construct() {
        $this->loadDeleteProducts();
    }

    private function loadDeleteProducts() {
        add_action('delete_all_products_ac', array($this, 'delete_all_products'));
        add_action('get_deleted_vf_products_ac', array($this, 'get_deleted_vf_products'));
        add_action('save_product_viztech_api_ac', array($this, 'save_product_viztech_api'), 10, 1 );
        add_action('delete_images_ac', array($this, 'delete_images'));
        add_action('delete_products_builder_ac', array($this, 'delete_products_builder'), 10, 1 );
        add_action('delete_products_ac', array($this, 'delete_products'), 10, 1 );
        add_action('check_empty_sku_ac', array($this, 'check_empty_sku'), 10, 1 );
        add_action('extra_clean_ini_ac', array($this, 'delete_if_not_vf_ini') );
        add_action('extra_clean', array($this, 'delete_if_not_vf'), 10, 1 );
        add_action('delete_exception_skus_ac', array($this, 'delete_exceptions') );        

        add_action('delete_vf_raw_data_ac', array($this, 'delete_vf_raw_data') );        
        add_action('remove_pending_crons_ac', array($this, 'remove_pending_crons') );        
        

    }


    /* These next functions delete all products without skus.
    TODO: A way to do the same thing for variations, if the variation is empty, needs to be deleted.
    */

    function check_empty_sku_ini() {

        // Get draft products.
        $args = array(
            'limit' => -1,
            'return' => 'ids'
        );

        $all_product_ids = wc_get_products( $args );

        $new_product_ids = array_chunk($all_product_ids, 500 );

        $transient_name = 'check_empty_sku';

        foreach ( $new_product_ids as $key => $new_product_id ) {

            $hook = 'check_empty_sku_ac';

            $args = array( $transient_name . '_' . $key ); 
            
            $if_has_scheduled = as_has_scheduled_action( $hook, $args );

            if ( false === $if_has_scheduled ) {

                set_transient($transient_name . '_' . $key, json_encode($new_product_id), DAY_IN_SECONDS );
                
                as_enqueue_async_action( $hook, $args );
            } 

        }

    }
    
	function check_empty_sku( $transient_name ) {

		$get_transient_sku_data = json_decode( get_transient( $transient_name ), true );

		foreach ( $get_transient_sku_data as $product_id ) {

            $product = wc_get_product($product_id);

            $sku = $product->get_sku();

            if ( empty($sku) ) {
               
                $del_prod = array();

                $del_prod = array( $product_id );

                as_enqueue_async_action( 'delete_products_ac', $del_prod );

            }
		
		}

		delete_transient( $transient_name );

	}


    /**
     * 
     * Initializing function for the delete_if_not_vf function in case you want to run it as a standalone function.
     *
     * @since 0.0.4
     *
     */

    function delete_if_not_vf_ini() {

        $getting_prods = new viztech_api_get_product_data();

		$builders = $getting_prods->get_builders();

		foreach ( $builders as $builder ) {

            //reset and get a fresh copy of all the product data
            as_enqueue_async_action('get_products_ini_ac');

            as_schedule_single_action( time() + 3600, 'extra_clean', array($builder) );

		}

    }

    /**
     * 
     * Need to redo this....
     *
     * @since 0.0.4
     *
     * @linked: viztech_api_format_products->clean_data
     * @linked: $this->delete_if_not_vf_ini
     * 
     * @param string builder id
     */

    function delete_if_not_vf( $vf_builder_id ) {

        $products = json_decode( get_option( 'products_' . $vf_builder_id ),true );
        
        $skus = wp_list_pluck($products, 'sku');

        $all_builders = json_decode(get_option('builder_categories'));

        $all_builders = ( ! empty( $all_builders ) ) ? $all_builders : array();

        $found_key = array_search(intval($vf_builder_id), array_column($all_builders, 'id'));

        $selected = $all_builders[$found_key];

        $name = $selected->name;

        $termy = get_term_by('name', $name, 'product_cat');

        if ( empty($termy) || empty($products) ) {
            return;
        }

        $args = array(
            'category' => array( $termy->slug ),
            'limit'     => -1
        );
        
        $existing_products = wc_get_products( $args );
        
        foreach ( $existing_products as $ex_product ) {
        
            $sku = $ex_product->get_sku();
        
            if ( ! in_array($sku, $skus) ) {

                $product_id = $ex_product->get_id();

                if ( $product_id ) {

                    $del_prod = array();

                    $del_prod = array( $product_id );

                    //as_enqueue_async_action( 'delete_products_ac', $del_prod );

                }
                
            }
        
        }

    }


    function delete_exceptions() {

        $exception_skus = json_decode(get_option( 'vf_sku_exceptions' ), true);

        $exception_skus = ! empty($exception_skus) ? $exception_skus : array();

        if ( empty($exception_skus) ) {
            return;
        }

        $exception_skus = array_map('trim', $exception_skus);

        foreach ( $exception_skus as $ex_sku ) {

            $exising_product_id = wc_get_product_id_by_sku( (string) $ex_sku );

            if ( ! empty($exising_product_id) ) {

                $del_prod = array();

                $del_prod = array( $exising_product_id );

                as_enqueue_async_action( 'delete_products_ac', $del_prod );

            }

        }

    }

    /**
     * 
     * Function to remove duplicate skus. It shouldn't happen but it does sometimes where the API creates two products with the same sku at the same exact time.
     *
     * @since 0.0.4
     * @link https://stackoverflow.com/questions/44514501/wordpress-woocommerce-delete-items-with-duplicat-skus
     */

    function delete_duplicate_skus() {

        global $wpdb;

        $results = $wpdb->get_results("SELECT post_id FROM ( select post_id, min(meta_id) as deletethis, max(meta_id) as keepthis, meta_value, meta_key, count(*) as c from {$wpdb->prefix}postmeta where meta_key like '_sku' and meta_value is not null and meta_value != ''  group by `meta_value` )  as skus where c > 1");

        foreach ( $results as $result ) {

            foreach ( $result as $prod_id ) {
                
                $del_prod = array();

                $del_prod = array( intval($prod_id) );

                as_enqueue_async_action( 'delete_products_ac', $del_prod );
            }
        
        }
    }

    function delete_cronies() {

        global $wpdb;

        $wpdb->query( "DELETE FROM {$wpdb->actionscheduler_actions} WHERE status IN ( 'complete', 'failed', 'canceled' );" );

    }

    function delete_vf_raw_data() {
        
        global $wpdb;

        $results = $wpdb->get_results( "Select option_name FROM {$wpdb->options} WHERE option_name LIKE ( 'vf_products_%' );" );
        
        foreach ( $results as $result ) {
            foreach ( $result as $name ) {
               update_option($name, '', 'no');
            }
        }

    }

    function delete_all_products() {
                
        update_option('create_products', '', 'no');

        update_option('vf_cats', '', 'no');

        update_option('all_cats_raw', '', 'no');

        update_option('all_terms', '', 'no');

        global $wpdb, $wp_version;

        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}woocommerce_attribute_taxonomies';" ) ) {
            $wc_attributes = array_filter( (array) $wpdb->get_col( "SELECT attribute_id FROM {$wpdb->prefix}woocommerce_attribute_taxonomies;" ) );
        } else {
            $wc_attributes = array();
        }
        
            $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE ( 'vf_att_terms_%' );" );
            $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE ( 'vf_products_%' );" );
            $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE ( 'products_%' );" );


            // Delete posts + data.
            $wpdb->query( "DELETE FROM {$wpdb->posts} WHERE post_type IN ( 'product', 'product_variation', 'shop_coupon', 'shop_order', 'shop_order_refund' );" );
            $wpdb->query( "DELETE meta FROM {$wpdb->postmeta} meta LEFT JOIN {$wpdb->posts} posts ON posts.ID = meta.post_id WHERE posts.ID IS NULL;" );

            $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE ( 'vf_att_terms_%' );" );

            $wpdb->query( "DELETE FROM {$wpdb->comments} WHERE comment_type IN ( 'order_note' );" );
            $wpdb->query( "DELETE meta FROM {$wpdb->commentmeta} meta LEFT JOIN {$wpdb->comments} comments ON comments.comment_ID = meta.comment_id WHERE comments.comment_ID IS NULL;" );
        

            // Delete terms if > WP 4.2 (term splitting was added in 4.2).
            if ( version_compare( $wp_version, '4.2', '>=' ) ) {
                // Delete term taxonomies.
                foreach ( array( 'product_cat', 'product_tag', 'product_shipping_class', 'product_type' ) as $_taxonomy ) {
                    $wpdb->delete(
                        $wpdb->term_taxonomy,
                        array(
                            'taxonomy' => $_taxonomy,
                        )
                    );
                }
        
                // Delete term attributes.
                foreach ( $wc_attributes as $_taxonomy ) {
                    wc_delete_attribute( $_taxonomy );
                }
        
                // Delete orphan relationships.
                $wpdb->query( "DELETE tr FROM {$wpdb->term_relationships} tr LEFT JOIN {$wpdb->posts} posts ON posts.ID = tr.object_id WHERE posts.ID IS NULL;" );
        
                // Delete orphan terms.
                $wpdb->query( "DELETE t FROM {$wpdb->terms} t LEFT JOIN {$wpdb->term_taxonomy} tt ON t.term_id = tt.term_id WHERE tt.term_id IS NULL;" );
        
                // Delete orphan term meta.
                if ( ! empty( $wpdb->termmeta ) ) {
                    $wpdb->query( "DELETE tm FROM {$wpdb->termmeta} tm LEFT JOIN {$wpdb->term_taxonomy} tt ON tm.term_id = tt.term_id WHERE tt.term_id IS NULL;" );
                }
            }
        
            // Clear any cached data that has been removed.
            wp_cache_flush();

    }

    function delete_products_builder( $builder_id ) {

        $args = array(
            'category' =>   array( (string) $builder_id ),
            'return'    =>  'ids',
            'limit'     => -1
        );

        $products = wc_get_products( $args );

        foreach ( $products as $product_id ) {

            $del_prod = array();

            $del_prod = array( $product_id );

            as_enqueue_async_action( 'delete_products_ac', $del_prod );
        }

    }

    //function pings the product database to see if it exists, if not, deletes it - works for variations too
    function delete_if_not_vf_check( $product_id ) {

        $client_api = new Woo_Client_API();
        $woo = $client_api->woo_client();

        $product = wc_get_product($product_id);

        $sku = $product->get_sku();

        $data = array();
        
        $data = array(
            'sku'   => $sku
        ); 

        // raw data from the product database, and encode it in json
        $product_data = json_encode($woo->get( 'products', $data ));

        // decode it to check to see if it's empty
        $product_data = json_decode( $product_data, true );
        
        // if array empty, use helper function to delete it
        if ( empty($product_data) ) {
            
            $this->delete_products($product_id);

        }

    }

    function delete_products( $product_id ) {

        $product = wc_get_product( (int) $product_id );

        if ( ! $product ) {
            return;
        }

        $kids = $product->get_children();

        if ( $kids ) {
            foreach ( $kids as $kid ) {
                do_action( 'woocommerce_before_delete_product_variation', $kid );
                wp_delete_post( $kid, true );
                do_action( 'woocommerce_delete_product_variation', $kid );
            }
        }

        wp_delete_post( $product_id, true );

    }

    function delete_images() {

        $args = array('post_type'=>'attachment','numberposts'=>-1,'post_status'=>null);
        
        $attachments = get_posts($args);

        if ( ! empty( $attachments ) ) {

            foreach ( $attachments as $post ) {
            
                wp_delete_attachment($post->ID, true);   
                
            }
            
            as_enqueue_async_action( 'delete_images_ac' );

        } else {

            as_unschedule_all_actions( 'delete_images_ac' );

        }
  
    }

    function get_deleted_vf_products() {

        $client_api = new Woo_Client_API();

        $woo = $client_api->woo_client();

        $data = (array) $woo->get('get_deleted');

        $products = array();

        $products = $data['products'];

        foreach ( $products as $product_sku ) {
            
            $existing_product = wc_get_product_id_by_sku( (string) $product_sku );

            if ( ! empty($existing_product) ) {
                wp_delete_post( $existing_product, true );
            }
            
        }


        $variations = array();

        $variations = $data['variations'];

        foreach ( $variations as $variation_sku ) {
            
            $existing_variation = wc_get_product_id_by_sku( (string) $variation_sku );

            $variation = ( ! empty($existing_variation) ) ? wc_get_product($existing_variation) : false;

            $type = ( false !== $variation ) ? $variation->get_type() : false;

            if ( 'variation' === $type ) {
                do_action( 'woocommerce_before_delete_product_variation', $key_remove );
                wp_delete_post( $existing_variation, true );
                do_action( 'woocommerce_delete_product_variation', $key_remove );

                $product_id = $variation->get_parent_id();

                $hook = 'save_product_viztech_api_ac';
              
                $args = array( $product_id );

                $if_has_scheduled = as_has_scheduled_action( $hook, $args );
                
                if ( false === $if_has_scheduled ) {
                    as_schedule_single_action( time() + 2400, $hook, $args );
                }

            }

        }

    }

    
    function save_product_viztech_api( $product_id ) {

        $product = wc_get_product( (int) $product_id );

        $product->save();

    }


    function remove_pending_crons() {
        as_unschedule_all_actions( 'create_products_ac' );
        as_unschedule_all_actions( 'create_variations_ac' );
        as_unschedule_all_actions( 'get_variation_data_ini_ac' );
        as_unschedule_all_actions( 'get_terms_ac' );
        as_unschedule_all_actions( 'clean_data_ac' );
        as_unschedule_all_actions( 'check_amounts_ac' );
        as_unschedule_all_actions( 'get_product_data_ac' );
        as_unschedule_all_actions( 'get_terms_ini_ac' );
        as_unschedule_all_actions( 'get_product_data_ac' );
        as_unschedule_all_actions( 'create_variations_ac_ini' );
        as_unschedule_all_actions( 'get_variation_data_ac' );
        as_unschedule_all_actions( 'replace_cats_atts_ac' );
    }

}

new viztech_api_delete_products();

?>