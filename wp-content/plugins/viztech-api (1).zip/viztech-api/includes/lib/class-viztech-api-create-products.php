<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Step 4. */

class viztech_api_create_products {

    function __construct() {
        $this->loadProductsCreate();
    }

    private function loadProductsCreate() {
		
		add_action('create_products_ac', array($this, 'create_products_ini'), 10, 2);
      
		add_action('create_variations_ac_ini', array($this, 'create_variations_for_viztech_ini'), 10, 1);

		add_action('create_variations_ac', array($this, 'create_variations_for_viztech'), 10, 1);
		
    }


	function create_products_ini( $index, $key ) {

		$products = array();

		$products = json_decode( get_option( $index ),true );

		$product = array();

		$product = $products[$key];

		if ( ! empty( $product ) ) {
			$this->create_products_for_viztech( $product );		
		}

	}

	/**
	 * Assigns taxonomy terms to a product.
	 *
	 * This function takes a product object, an array of terms, and an optional taxonomy parameter.
	 * It checks if the term IDs exist in the specified taxonomy and assigns them to the product.
	 *
	 * @param WC_Product $product The product object to assign taxonomy terms to.
	 * @param array      $terms   An array of terms containing their IDs.
	 * @param string     $taxonomy Optional. The taxonomy to assign the terms to. Default is 'cat' (category).
	 *
	 * @return WC_Product The modified product object with assigned taxonomy terms.
	*/

	function save_taxonomy_terms_viztech( $product, $terms, $taxonomy = 'cat' ) {
		$term_ids = wp_list_pluck( $terms, 'id' );

		if ( 'cat' === $taxonomy ) {

			// check to see if category id's exist before assigning them, exit if any category doesn't exist
			foreach ( $term_ids as $term_id ) {
				$term_exists = term_exists( $term_id, 'product_cat' );
				if ( ! $term_exists ) {
					exit;
				}
			}

			$product->set_category_ids( $term_ids );
		} elseif ( 'tag' === $taxonomy ) {
			$product->set_tag_ids( $term_ids );
		}

		return $product;
	}

	/**
	 * Sets default attributes for a product.
	 *
	 * This function takes a product object and a request array containing default attributes.
	 * It assigns the default attributes to the product based on the provided information.
	 *
	 * @param WC_Product $product  The product object to set default attributes for.
	 * @param array      $request  The request array containing default attribute information.
	 *
	 * @return WC_Product The modified product object with default attributes set.
	 */

	function save_default_attributes( $product, $request ) {
		if ( isset( $request['default_attributes'] ) && is_array( $request['default_attributes'] ) ) {

			$attributes         = $product->get_attributes();
			$default_attributes = array();

			foreach ( $request['default_attributes'] as $attribute ) {
				$attribute_id   = 0;
				$attribute_name = '';

				// Check ID for global attributes or name for product attributes.
				if ( ! empty( $attribute['id'] ) ) {
					$attribute_id   = absint( $attribute['id'] );
					$attribute_name = wc_attribute_taxonomy_name_by_id( $attribute_id );
				} elseif ( ! empty( $attribute['name'] ) ) {
					$attribute_name = sanitize_title( $attribute['name'] );
				}

				if ( ! $attribute_id && ! $attribute_name ) {
					continue;
				}

				if ( isset( $attributes[ $attribute_name ] ) ) {
					$_attribute = $attributes[ $attribute_name ];

					if ( $_attribute['is_variation'] ) {
						$value = isset( $attribute['option'] ) ? wc_clean( stripslashes( $attribute['option'] ) ) : '';

						if ( ! empty( $_attribute['is_taxonomy'] ) ) {
							// If dealing with a taxonomy, we need to get the slug from the name posted to the API.
							$term = get_term_by( 'name', $value, $attribute_name );

							if ( $term && ! is_wp_error( $term ) ) {
								$value = $term->slug;
							} else {
								$value = sanitize_title( $value );
							}
						}

						if ( $value ) {
							$default_attributes[ $attribute_name ] = $value;
						}
					}
				}
			}

			$product->set_default_attributes( $default_attributes );
		}

		return $product;
	}

	/**
	 * Sets product images for a given product.
	 *
	 * This function takes a product object and an array of images.
	 * It assigns the images to the product by setting the featured image and gallery images.
	 *
	 * @param WC_Product $product The product object to set images for.
	 * @param array      $images  An array of images containing their source, alt text, and name.
	 *
	 * @return WC_Product The modified product object with assigned images.
	 *
	 * @throws WC_REST_Exception If an invalid image ID is encountered.
	 */


    function set_product_images_viztech( $product, $images ) {
		$images = is_array( $images ) ? array_filter( $images ) : array();

		if ( ! empty( $images ) ) {
			$gallery = array();

			foreach ( $images as $index => $image ) {

				if ( isset( $image['src'] ) ) {

					$formatting_prods = new viztech_api_format_products();

					$attachment_id = $formatting_prods->get_attachment_id_from_url_viztech($image['src'], $product->get_id());

				}

				if ( ! wp_attachment_is_image( $attachment_id ) ) {
					/* translators: %s: image ID */
					throw new WC_REST_Exception( 'woocommerce_product_invalid_image_id', sprintf( __( '#%s is an invalid image ID.', 'woocommerce' ), $attachment_id ), 400 );
				}

				$featured_image = $product->get_image_id();

				if ( 0 === $index ) {
					$product->set_image_id( $attachment_id );
				} else {
					$gallery[] = $attachment_id;
				}

				// Set the image alt if present.
				if ( ! empty( $image['alt'] ) ) {
					update_post_meta( $attachment_id, '_wp_attachment_image_alt', wc_clean( $image['alt'] ) );
				}

				// Set the image name if present.
				if ( ! empty( $image['name'] ) ) {
					wp_update_post(
						array(
							'ID'         => $attachment_id,
							'post_title' => $image['name'],
						)
					);
				}
			}

			$product->set_gallery_image_ids( $gallery );
		} else {
			$product->set_image_id( '' );
			$product->set_gallery_image_ids( array() );
		}

		return $product;
	}

    function create_products_for_viztech( $request, $creating = false ) {

		$id = isset( $request['id'] ) ? absint( $request['id'] ) : 0;

		//$existing_product_id = ( ! empty(wc_get_product_id_by_sku( $request['sku'] ) ) ) ? wc_get_product_id_by_sku( $request['sku'] ) : 0;

		$formatting_prods = new viztech_api_format_products();

		$existing_product_id = $formatting_prods->get_existing_product( $request );

		$existing_product_id = ! empty( $existing_product_id ) ? $existing_product_id : 0;

		$id = ( 0 === $id ) ? $existing_product_id : $id;

		// Type is the most important part here because we need to be using the correct class and methods.
		if ( isset( $request['type'] ) ) {
			
			$classname = WC_Product_Factory::get_classname_from_product_type( $request['type'] );

			if ( ! class_exists( $classname ) ) {
				$classname = 'WC_Product_Simple';
			}

			$product = new $classname( $id );

			
		} elseif ( isset( $request['id'] ) ) {
			
			$product = wc_get_product( $id );

		} else {

			if ( 0 !== $id ) {
				
				$product = wc_get_product( $existing_product_id );

			} else {
				$product = new WC_Product_Simple();
			}
			
		}

		//variables we need to make for the variable data
		
		if ( isset( $request['vf_id'] ) ) {
			$vf_id = (int) $request['vf_id'];
		}

		if ( isset( $request['builder'] ) ) {
			$builder = (int) $request['builder'];
		}

		if ( isset( $request['pages'] ) ) {
			$pages = (int) $request['pages'];
		}
		

		//Exit if both existing and new dates match up exactly

		// $current_product_date = $product->get_date_created();

		// $current_product_date = date("Ymd:H:i:s", strtotime($current_product_date));

		// $new_product_date = $request['date_modified_gmt'];

		// $new_product_date = date("Ymd:H:i:s", strtotime($new_product_date));

		// if ( $current_product_date === $new_product_date ) {
			
		// 	if ( $product->is_type( 'variable' ) ) {

		// 		$id = $product->get_id();
			
		// 		$var_data = array();
		
		// 		$var_data = array($id, $vf_id, $builder, $pages);
		
		// 		as_enqueue_async_action( 'get_variation_data_ini_ac', $var_data );

		// 	}

		// 	return;
		// }


		if ( 'variation' === $product->get_type() ) {
			return new WP_Error(
				"woocommerce_rest_invalid_{$this->post_type}_id",
				__( 'To manipulate product variations you should use the /products/&lt;product_id&gt;/variations/&lt;id&gt; endpoint.', 'woocommerce' ),
				array(
					'status' => 404,
				)
			);
		}

		// Post title.
		if ( isset( $request['name'] ) ) {
            $product->set_name( wp_filter_post_kses( $request['name'] ) );
		}

		// Post content.
		if ( isset( $request['description'] ) ) {
			$product->set_description( wp_filter_post_kses( $request['description'] ) );
		}

		// Post excerpt.
		if ( isset( $request['short_description'] ) ) {
			$product->set_short_description( wp_filter_post_kses( $request['short_description'] ) );
		}

		// Post status.
		if ( isset( $request['status'] ) ) {
			$product->set_status( get_post_status_object( $request['status'] ) ? $request['status'] : 'draft' );
		}

		// Post slug.
		if ( isset( $request['slug'] ) ) {
			$product->set_slug( $request['slug'] );
		}

		// Menu order.
		if ( isset( $request['menu_order'] ) ) {
			$product->set_menu_order( $request['menu_order'] );
		}

		// Comment status.
		if ( isset( $request['reviews_allowed'] ) ) {
			$product->set_reviews_allowed( $request['reviews_allowed'] );
		}

		// Virtual.
	
		// Tax status.
		

		// Tax Class.
		

		// Catalog Visibility.
	

		// Purchase Note.

		// Featured Product.

		// Shipping data.


		// SKU.
		if ( isset( $request['sku'] ) ) {
			$product->set_sku( wc_clean( $request['sku'] ) );
		}

		// Attributes.
		if ( isset( $request['attributes'] ) ) {
			$attributes = array();

			foreach ( $request['attributes'] as $attribute ) {
				$attribute_id   = 0;
				$attribute_name = '';

				// Check ID for global attributes or name for product attributes.
				if ( ! empty( $attribute['id'] ) ) {
					$attribute_id   = absint( $attribute['id'] );
					$attribute_name = wc_attribute_taxonomy_name_by_id( $attribute_id );
				} elseif ( ! empty( $attribute['name'] ) ) {
					$attribute_name = wc_clean( $attribute['name'] );
				}

				if ( ! $attribute_id && ! $attribute_name ) {
					continue;
				}

				if ( $attribute_id ) {

					if ( isset( $attribute['options'] ) ) {
						$options = $attribute['options'];

						if ( ! is_array( $attribute['options'] ) ) {
							// Text based attributes - Posted values are term names.
							$options = explode( WC_DELIMITER, $options );
						}

						$values = array_map( 'wc_sanitize_term_text_based', $options );
						$values = array_filter( $values, 'strlen' );


					} else {
						$values = array();
					}

					if ( ! empty( $values ) ) {
						// Add attribute to array, but don't set values.
						$attribute_object = new WC_Product_Attribute();
						$attribute_object->set_id( $attribute_id );
						$attribute_object->set_name( $attribute_name );
						$attribute_object->set_options( $values );
						$attribute_object->set_position( isset( $attribute['position'] ) ? (string) absint( $attribute['position'] ) : '0' );
						$attribute_object->set_visible( ( isset( $attribute['visible'] ) && $attribute['visible'] ) ? 1 : 0 );
						$attribute_object->set_variation( ( isset( $attribute['variation'] ) && $attribute['variation'] ) ? 1 : 0 );
						$attributes[] = $attribute_object;
					}
				} elseif ( isset( $attribute['options'] ) ) {
					// Custom attribute - Add attribute to array and set the values.
					if ( is_array( $attribute['options'] ) ) {
						$values = $attribute['options'];
					} else {
						$values = explode( WC_DELIMITER, $attribute['options'] );
					}
					$attribute_object = new WC_Product_Attribute();
					$attribute_object->set_name( $attribute_name );
					$attribute_object->set_options( $values );
					$attribute_object->set_position( isset( $attribute['position'] ) ? (string) absint( $attribute['position'] ) : '0' );
					$attribute_object->set_visible( ( isset( $attribute['visible'] ) && $attribute['visible'] ) ? 1 : 0 );
					$attribute_object->set_variation( ( isset( $attribute['variation'] ) && $attribute['variation'] ) ? 1 : 0 );
					$attributes[] = $attribute_object;
				}
			}
			$product->set_attributes( $attributes );
		}

		// Sales and prices.
		if ( in_array( $product->get_type(), array( 'variable', 'grouped' ), true ) ) {
			$product->set_regular_price( '' );
			$product->set_price( '' );
		} else {
			// Regular Price.
			if ( isset( $request['regular_price'] ) ) {
				$product->set_regular_price( $request['regular_price'] );
			}

		}

		// Product parent ID.
		if ( isset( $request['parent_id'] ) ) {
			$product->set_parent_id( $request['parent_id'] );
		}

		// Sold individually.
		

		// Stock status; stock_status has priority over in_stock.
		

		// Stock data.
	

		// Upsells.


		// Cross sells.


		if ( isset( $request['categories'] ) && is_array( $request['categories'] ) ) {

			$product = $this->save_taxonomy_terms_viztech( $product, $request['categories'] );

		}


		// Product tags.
		if ( isset( $request['tags'] ) && is_array( $request['tags'] ) ) {
			$new_tags = array();

			foreach ( $request['tags'] as $tag ) {
				if ( ! isset( $tag['name'] ) ) {
					$new_tags[] = $tag;
					continue;
				}

				if ( ! term_exists( $tag['name'], 'product_tag' ) ) {
					// Create the tag if it doesn't exist.
					$term = wp_insert_term( $tag['name'], 'product_tag' );

					if ( ! is_wp_error( $term ) ) {
						$new_tags[] = array(
							'id' => $term['term_id'],
						);

						continue;
					}
				} else {
					// Tag exists, assume user wants to set the product with this tag.
					$new_tags[] = array(
						'id' => get_term_by( 'name', $tag['name'], 'product_tag' )->term_id,
					);
				}
			}

			$product = $this->save_taxonomy_terms_viztech( $product, $new_tags, 'tag' );
		}

		// Downloadable.


		// Downloadable options.


		// Product url and button text for external products.
	

		// Save default attributes for variable products.
		
		// Save default attributes for variable products.
		if ( $product->is_type( 'variable' ) ) {

			$product = $this->save_default_attributes( $product, $request );
			

		}

		// Set children for a grouped product.

		// Check for featured/gallery images, upload it and set it.
		if ( isset( $request['images'] ) ) {
			$product = $this->set_product_images_viztech( $product, $request['images'] );
		}

		// Allow set meta_data.
		if ( is_array( $request['meta_data'] ) ) {
			foreach ( $request['meta_data'] as $meta_key => $meta ) {
				$product->update_meta_data( $meta['key'], $meta['value'], isset( $meta['id'] ) ? $meta['id'] : '' );
			}
		}

		if ( ! empty( $request['date_modified'] ) ) {
			$date = rest_parse_date( $request['date_modified'] );

			if ( $date ) {
				$product->set_date_created( $date );
			}
		}

		if ( ! empty( $request['date_modified_gmt'] ) ) {
			$date = rest_parse_date( $request['date_modified_gmt'], true );

			if ( $date ) {
				$product->set_date_created( $date );
			}
		}

            
        if ( ! is_null( $product ) ) {
          	
			$return = $product->save();

        }

		if ( $product->is_type( 'variable' ) ) {

			$id = $product->get_id();
			
			$var_data = array();
	
			$var_data = array($id, $vf_id, $builder, $pages);
	
			as_enqueue_async_action( 'get_variation_data_ini_ac', $var_data );
			
		}

	}

	function create_variations_for_viztech_ini( $transient_name ) {

		$get_transient_variation_data = json_decode( get_transient( $transient_name ),true );

		foreach ( $get_transient_variation_data as $variation_data ) {

			$this->create_variations_for_viztech( $variation_data );

		}

		delete_transient( $transient_name );

	}

	function create_variations_for_viztech( $request, $creating = false ) {
		
		if ( isset( $request['id'] ) ) {
			$variation = wc_get_product( absint( $request['id'] ) );

		} else {

			$formatting_prods = new viztech_api_format_products();

			$existing_variation_id = $formatting_prods->get_existing_product( $request );

			$existing_variation = ( ! empty( $existing_variation_id ) ) ? $existing_variation_id : false ;

			if ( false !== $existing_variation ) {
				
				$variation = wc_get_product( absint( $existing_variation ) );
			} else {
				$variation = new WC_Product_Variation();
			}

		}


		$variation->set_parent_id( absint( $request['parent_id'] ) );

		// Status.
		if ( isset( $request['status'] ) ) {
			$variation->set_status( get_post_status_object( $request['status'] ) ? $request['status'] : 'draft' );
		}

		// SKU.
		if ( isset( $request['sku'] ) ) {
			
			$parent = wc_get_product( $variation->get_parent_id() );

			$parent_sku = $parent->get_sku();

			if ( $parent_sku === $request['sku'] ) {
				return;
			} else {
				$variation->set_sku( wc_clean( $request['sku'] ) );
			}

			
		}

		// Thumbnail.

		if ( isset( $request['image'] ) ) {
			if ( is_array( $request['image'] ) ) {
				$variation = $this->set_variation_image_viztech( $variation, $request['image'] );
			} else {
				$variation->set_image_id( '' );
			}
		}

		// Virtual variation.
		
		// Downloadable variation.
		
		// Downloads.

		// Shipping data.

		// Stock handling.

		// Regular Price.
		if ( isset( $request['regular_price'] ) ) {
			$variation->set_regular_price( $request['regular_price'] );
		}

		// Sale Price.

		if ( ! empty( $request['date_modified'] ) ) {
			$date = rest_parse_date( $request['date_modified'] );

			if ( $date ) {
				$variation->set_date_created( $date );
			}
		}

		if ( ! empty( $request['date_modified_gmt'] ) ) {
			$date = rest_parse_date( $request['date_modified_gmt'], true );

			if ( $date ) {
				$variation->set_date_created( $date );
			}
		}

		// Description.
		if ( isset( $request['description'] ) ) {
			$variation->set_description( wp_kses_post( $request['description'] ) );
		}

		// Update taxonomies.
		if ( isset( $request['attributes'] ) ) {
			$attributes = array();
			$parent     = wc_get_product( $variation->get_parent_id() );

			if ( ! $parent ) {
				return new WP_Error(
					// Translators: %d parent ID.
					"woocommerce_rest_{$this->post_type}_invalid_parent",
					__( 'Cannot set attributes due to invalid parent product.', 'woocommerce' ),
					array( 'status' => 404 )
				);
			}

			$parent_attributes = $parent->get_attributes();

			foreach ( $request['attributes'] as $attribute ) {
				$attribute_id   = 0;
				$attribute_name = '';

				// Check ID for global attributes or name for product attributes.
				if ( ! empty( $attribute['id'] ) ) {
					$attribute_id   = absint( $attribute['id'] );
					$attribute_name = wc_attribute_taxonomy_name_by_id( $attribute_id );
				} elseif ( ! empty( $attribute['name'] ) ) {
					$attribute_name = sanitize_title( $attribute['name'] );
				}

				if ( ! $attribute_id && ! $attribute_name ) {
					continue;
				}

				if ( ! isset( $parent_attributes[ $attribute_name ] ) || ! $parent_attributes[ $attribute_name ]->get_variation() ) {
					continue;
				}

				$attribute_key   = sanitize_title( $parent_attributes[ $attribute_name ]->get_name() );
				$attribute_value = isset( $attribute['option'] ) ? wc_clean( stripslashes( $attribute['option'] ) ) : '';

				if ( $parent_attributes[ $attribute_name ]->is_taxonomy() ) {
					// If dealing with a taxonomy, we need to get the slug from the name posted to the API.
					$term = get_term_by( 'name', $attribute_value, $attribute_name );

					if ( $term && ! is_wp_error( $term ) ) {
						$attribute_value = $term->slug;
					} else {
						$attribute_value = sanitize_title( $attribute_value );
					}
				}

				$attributes[ $attribute_key ] = $attribute_value;
			}

			$variation->set_attributes( $attributes );
		}

		// Menu order.
		if ( $request['menu_order'] ) {
			$variation->set_menu_order( $request['menu_order'] );
		}

		// Meta data.
		if ( is_array( $request['meta_data'] ) ) {
			foreach ( $request['meta_data'] as $meta ) {
				$variation->update_meta_data( $meta['key'], $meta['value'], isset( $meta['id'] ) ? $meta['id'] : '' );
			}
		}

		$return = $variation->save();		

	}

	/**
	 * Sets the image for a variation.
	 *
	 * This function takes a variation object and an image array.
	 * It assigns the image to the variation by setting the variation's image ID, alt text, and name.
	 *
	 * @param WC_Product_Variation $variation The variation object to set the image for.
	 * @param array                $image     An array containing the image source, alt text, and name.
	 *
	 * @return WC_Product_Variation The modified variation object with the assigned image.
	 *
	 * @throws WC_REST_Exception If an invalid image ID is encountered.
	 */

	function set_variation_image_viztech( $variation, $image ) {
		
		if ( isset( $image['src'] ) ) {

			$formatting_prods = new viztech_api_format_products();

			$image_exists = false;

			$attachment_id = $formatting_prods->get_attachment_id_from_url_viztech( $image['src'], $variation->get_id() );

		} else {
			$variation->set_image_id( '' );
			return $variation;
		}
		

		if ( ! wp_attachment_is_image( $attachment_id ) ) {
			/* translators: %s: attachment ID */
			throw new WC_REST_Exception( 'woocommerce_variation_invalid_image_id', sprintf( __( '#%s is an invalid image ID.', 'woocommerce' ), $attachment_id ), 400 );
		}

		$variation->set_image_id( $attachment_id );

		// Set the image alt if present.
		if ( ! empty( $image['alt'] ) ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', wc_clean( $image['alt'] ) );
		}

		// Set the image name if present.
		if ( ! empty( $image['name'] ) ) {
			wp_update_post(
				array(
					'ID'         => $attachment_id,
					'post_title' => $image['name'],
				)
			);
		}

		return $variation;
	} 

}    

new viztech_api_create_products();

?>