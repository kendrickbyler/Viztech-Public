<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Step 2. */

/* These commands are used to take the raw data from Viztech Furniture and make it work for the new site. */

class viztech_api_format_products {

    function __construct() {
        $this->loadFormatProducts();
    }
    
	private function loadFormatProducts() {
       
		add_action('clean_data_ini', array($this, 'clean_data_initate') );
        
		add_action('clean_data_ac', array($this, 'clean_data'), 10, 2);                

		add_action('new_defaults_if_missing_ac', array($this, 'new_defaults_if_missing') );
	
		add_action('get_vf_ids_ini_ac', array($this, 'get_vf_ids_ini') );

		add_action('get_vf_ids_ac', array($this, 'get_vf_ids'), 10, 1 );

		add_action('clean_single_product_ac', array($this, 'clean_single_product'), 10, 2 );

    }

	function clean_data_initate() {
		
		$getting_prods = new viztech_api_get_product_data();

		$builders = $getting_prods->get_builders();

		foreach ( $builders as $builder ) {

			$args = array();

			$index = 'vf_products_'.$builder;

			$args = array( $index, $builder );

			$hook = 'clean_data_ac';

			$if_has_scheduled = as_has_scheduled_action( $hook, $args );

			if ( false === $if_has_scheduled ) {
				as_enqueue_async_action( 'clean_data_ac', $builder_data );
			}

		}

	}

	function clean_data( $index, $category ) {

		$product_data_array = array();

		$product_data_array = json_decode(get_option($index),true);

		$new_prod_array = array();

		$exception_skus = json_decode(get_option( 'vf_sku_exceptions' ), true);

		$exception_skus = ! empty($exception_skus) ? $exception_skus : array();

		foreach ( $product_data_array as $product ) {

			$product = $this->replace_info($product, $category);
			
			$product = $this->check_if_existing($product);

			$product = $this->new_meta_data($product);

			$product = $this->short_description($product);

			$product = $this->categories_syncing($product);
			
			$product = $this->do_pricing($product, $category);

			$sku = $product['sku'];

			if ( ! empty($sku) && ! in_array( $sku, $exception_skus ) ) {
				$new_prod_array[$product['vf_id']] = $product;
			}

		}

		update_option('products_'.$category, json_encode($new_prod_array, JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS), 'no');

		$hook = 'extract_terms';

		$args = array( $category );

		$if_has_scheduled = as_has_scheduled_action( $hook, $args );

		if ( false === $if_has_scheduled ) {
			as_enqueue_async_action( $hook, $args );
		}

		// maybe use below code, depends - it makes so if a product in the local database but not in the VF databse that it removes it

		// $extra_clean_hook = 'extra_clean';

		// $if_extra_clean_has_scheduled = as_has_scheduled_action( $extra_clean_hook, $args );
	
		// if ( false === $if_extra_clean_has_scheduled ) {
		// 	as_schedule_single_action( time() + 30000, $if_extra_clean_has_scheduled, $args );
		// }
		
	}

	function clean_single_product( $product_id, $category ) {

		$raw_product_data_array = array();

		$raw_product_data_array = json_decode(get_option('vf_products_'.$category),true);

		$product = $raw_product_data_array[$product_id];

		if ( empty($product) ) {
			return;
		}

		$exception_skus = json_decode(get_option( 'vf_sku_exceptions' ), true);

		$exception_skus = ! empty($exception_skus) ? $exception_skus : array();

		$product = $this->replace_info($product, $category);
			
		$product = $this->check_if_existing($product);

		$product = $this->new_meta_data($product);

		$product = $this->short_description($product);

		$product = $this->categories_syncing($product);
		
		$product = $this->do_pricing($product, $category);

		$sku = $product['sku'];

		$syncing_terms_cats = new viztech_api_terms_categories();

		if ( ! empty($sku) && ! in_array( $sku, $exception_skus ) ) {
		
			$new_product_data_array = array();

			$new_product_data_array[$product_id] = $product;

			$old_clean_data = array();

			$old_clean_data = json_decode(get_option('products_'.$category),true);

			$old_clean_data = ! empty($old_clean_data) ? $old_clean_data : array();

			$all_data = array();

			$all_data = $new_product_data_array + $old_clean_data;

			update_option('products_'.$category, json_encode($all_data, JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS), 'no');

			$syncing_terms_cats->extract_terms_product($product_id, $category);

		}

	}

	
	/**
	 * 
	 * Sets the categories based on whether or not the product is a new product as well as the current setting whether or not to sync cats.
	 *
	 * @since 0.0.6
	 *
	 * @param string var Default add to cart text.
	 * @return string Text displayed at add to cart.
	 */

	function categories_syncing( $request ) {

		$syncing_options = (string) get_option('wpt_vf_sync_categories');

		switch ($syncing_options) {

			case 'always_sync':
				$not_sync_cats = false;
				break;
		
			case 'never_sync':
				$not_sync_cats = true;
				break;
			
			case 'new_product':
			default:
				$not_sync_cats = ( isset($request['id']) ) ? true : false;
				break;
		
		}


		if ( true === $not_sync_cats ) {
			unset($request['categories']);
		}

		return $request;

	}

	function replace_info($product, $category) {

		$product['vf_id'] = $product['id'];

		// unset($product['id']);

		$product['builder'] = $category;

		$product['cleaned'] = 'yes';

		return $product;

	}

	function check_if_existing($product) {
		
		$existing_product_id = $this->get_existing_product( $product );

		if ( ! empty( $existing_product_id ) ) {
			
			$product['id'] = $existing_product_id;                      
			
		} else {

			unset($product['id']);

		}

		return $product;

	}

	function new_meta_data($product) {
		
		$new_meta = array();

		foreach ( $product['meta_data'] as $key => $meta ) {
			if ( str_contains($meta['key'], 'swatch') || $meta['key'] === 'custom_related_products' || $meta['key'] === 'threed_tab_content' || $meta['key'] === 'ws_addons'  ) {

				if ( $meta['key'] === '_swatch_type_options' ) {

					$vals = is_array($meta['value']) ? $meta['value'] : array();

					$new_val = array();
			
					if ( $vals['df7b787bf7cb290a8bfad3e51d35efa9'] ) {
								 
						$meta['value']['c2a145b5a3d762c56ce17939939bc84d'] = $meta['value']['df7b787bf7cb290a8bfad3e51d35efa9'];    
					
						unset($meta['value']['df7b787bf7cb290a8bfad3e51d35efa9']);
						
						$new_val = $meta['value'];
			
					} else {

						$new_val = $meta['value'];						

					}
			
					$meta['value'] = $new_val;

				} 

				unset($meta['id']);

				$new_meta[] = $meta;
			}

		}

		if ( ! empty($product['price']) && isset($product['price']) ) {

			$vf_price = array( 'key' => '_vf_price', 'value' => $product['price'] );

			$new_meta[] = $vf_price;

		}

		if ( ! empty($product['regular_price']) && isset($product['regular_price']) ) {

			$vf_regular_price = array( 'key' => '_vf_regular_price', 'value' => $product['regular_price'] );

			$new_meta[] = $vf_regular_price;

		}

		$vf_id = array( 'key' => '_vf_id', 'value' => $product['vf_id'] );

		$new_meta[] = $vf_id;

		$product['meta_data'] = $new_meta;

		return $product;

	}

	function do_pricing( $product, $category ) {

		$no_pricing = (string) get_option('wpt_vf_sync_price');

		if ( ! empty($no_pricing) ) {

			$product['regular_price'] = 0;

			$product['price'] = 0;

		} else {
			$price_increase_overall = (float) get_option('wpt_vf_increase_price');

			$price_increase_builder = (float) get_option('wpt_vf_increase_price_builder'.$category);
	
			$price_increase = ( ! empty( $price_increase_builder ) ) ? $price_increase_builder : $price_increase_overall; 
	
			$regular_price = floatval($product['regular_price']);
	
			if ( ! empty($regular_price) && ! empty($price_increase) ) {
				
				$new_price = $regular_price + (($regular_price * $price_increase) / 100);
	
				$product['regular_price'] = ceil($new_price);
	
			}
	
			$price = floatval($product['price']);
	
			if ( ! empty($price) && ! empty($price_increase) ) {
				
				$new_price = $price + (($price * $price_increase) / 100);
	
				$product['price'] = ceil($new_price);
			}
		}

		return $product;

	}


	function short_description($product) {

		$not_sync_short_desc = (string) get_option('wpt_vf_sync_short_description');

		if ( 'on' === $not_sync_short_desc ) {

			if ( isset( $product['id'] ) ) {

				$current_product = wc_get_product($product['id']);

				$product['short_description'] = $current_product->get_short_description();

			} else {
				unset($product['short_description']);
			}

		}
		
		return $product;

	}


	function swap_attributes($variation) {

		$atts = array();

		foreach ( $variation['attributes'] as $att_key => $att ) {
			
			$id = wc_attribute_taxonomy_id_by_name($att['name']);

			$new_att = ( ! empty($id) ) ? $id : false;

			if ( $new_att !== false ) {

				$att['vf_att_id'] = $att['id'];

				$att['id'] = $new_att;

				$atts[] = $att;

			} elseif ( 0 === $att_key ) { 

				$att['id'] = $att_key;

				$atts[] = $att;

			}  

		}


		if ( ! empty($atts) ) {

			$variation['attributes'] = $atts;
	
		} else {

			unset($variation['attributes']);

		} 
		
		return $variation;

	}


	function clean_variation_data($variation_data, $this_id, $this_builder, $page) {

		$new_variation_data = array();

		//$creating_prods = new viztech_api_create_products();

		$getting_prods = new viztech_api_get_product_data();

		foreach ( $variation_data as $variation ) {

			$variation = $getting_prods->remove_data($variation);

			$variation = $this->replace_info( $variation, $this_builder );

			$variation = $this->check_if_existing($variation);

			$variation = $this->new_meta_data($variation);

			$variation = $this->do_pricing( $variation, $this_builder );
	
			$variation = $this->swap_attributes($variation);

			$variation['parent_id'] = $this_id;

			$parent = wc_get_product($this_id);

			$parent_sku = $parent->get_sku();
			
			$key = $variation['vf_id'];

			if ( $variation['sku'] !== $parent_sku ) {

				$hook = 'create_variations_ac';

				$args = array($variation);

				$if_has_scheduled = as_has_scheduled_action( $hook, $args );

				if ( false === $if_has_scheduled ) {
					as_enqueue_async_action( $hook, $args );
				}

				//$creating_prods->create_variations_for_viztech( $variation );
		
				//$new_variation_data[$key] = $variation;

			} 
			
		}


		// $old_variation_data = json_decode( get_option( 'variations_' . $this_builder ),true );

		// $old_variation_data = ! empty($old_variation_data) ? $old_variation_data : array();  

		// $all_varations = array();

		// $all_varations = $new_variation_data + $old_variation_data;

		// update_option( 'variations_' . $this_builder, json_encode($all_varations), 'no' );

		//$transient_name = 'create_variations_' . $this_builder . '_' . $this_id . '_' . $page;
		
		//$this->initiate_variations_building( $new_variation_data, $transient_name );

	}

	function initiate_variations_building( $new_variation_data, $transient_name ) {

		$new_var_arr = array_chunk($new_variation_data, 10 );

		foreach ( $new_var_arr as $key => $var_ar ) {

			$hook = 'create_variations_ac_ini';

			$args = array( $transient_name . '_' . $key ); 

			$if_has_scheduled = as_has_scheduled_action( $hook, $args );

			if ( false === $if_has_scheduled ) {

				set_transient($transient_name . '_' . $key, json_encode($var_ar), WEEK_IN_SECONDS );
				
				as_enqueue_async_action( $hook, $args );
			}

		}
		
	}


	function new_defaults_if_missing() {

		$args = array(
			'type' => 'variable',
			'limit' => -1,
		);

		$products = wc_get_products( $args );

		foreach ( $products as $key => $product ) {

    		$defaults = $product->get_default_attributes();

		    $atts = $product->get_attributes();

    		$new = false; 

			foreach ( $defaults as $key => $default_val ) {

				$termmy = get_term_by('slug', $default_val, $key);

				if ( false === $termmy ) {
					
					$option = $atts[$key]['options'][0];

					$term_obj = get_term_by( 'term_id', $option, $key );

					$term_slug = $term_obj->slug;
						
					$defaults[$key] = $term_slug;

					$new = true;

				} 

			}

			if ( $new === true ) {
				
				update_post_meta($product->get_id(), '_default_attributes', $defaults);

			}

		}


	}

	function make_swatches_tables() {

		$args = array(
		    'type' => 'variable',
		    'limit' => -1
		);

		$products = wc_get_products( $args );

		foreach ( $products as $prod ) {

		    $meta = $prod->get_meta('_swatch_type_options');

		    if ( array_key_exists( 'df7b787bf7cb290a8bfad3e51d35efa9', $meta ) ) {

			    $meta['c2a145b5a3d762c56ce17939939bc84d'] = $meta['df7b787bf7cb290a8bfad3e51d35efa9'];

			    unset($meta['df7b787bf7cb290a8bfad3e51d35efa9']);
			
			   	$prod->update_meta_data('_swatch_type_options', $meta);
			
			    $prod->save();    

		    }

		}

	}

	function get_existing_product( $product ) {

		$existing_product_id = wc_get_product_id_by_sku( $product['sku'] );

		if ( empty( $existing_product_id ) ) {

			$args = array(
				'post_type' => array('product_variation', 'product'),
				'meta_key' => '_vf_id',
				'meta_value' => $product['vf_id'], //'meta_value' => array('yes'),
				'meta_compare' => '=', //'meta_compare' => 'NOT IN'
				'fields'    => 'ids',
			);
			
			$post = get_posts($args);
			
			if ( $post ) {
				$existing_product_id = $post[0];
			} 

		}

		return $existing_product_id;

	}

	function get_vf_ids_ini() {

		$args = array(
			'post_type' => array('product_variation', 'product'),
			'fields'    => 'ids',
			'posts_per_page' => -1,
			'meta_query' => array(
				array(
				 'key' => '_vf_id',
				 'compare' => 'NOT EXISTS' // this should work...
				),
			)
		);
		
		$posts = get_posts($args);

		foreach ( $posts as $post_id ) {

			as_enqueue_async_action( 'get_vf_ids_ac', array( $post_id ) );

		}
		

	}

	function get_vf_ids( $post_id ) {

		$product = wc_get_product( (int) $post_id );

		$sku = $product->get_sku();

		if ( ! empty($sku) ) {

			$data = array(
				'status'    => 'publish',
				'sku'       => $sku
			);
			
			$client_api = new Woo_Client_API();
					
			$woo = $client_api->woo_client();

			$product_data = json_encode($woo->get( 'products', $data ));

			$product_data = json_decode( $product_data, true );

			$id = $product_data[0]['id'];

			if ( ! empty($id) ) {
				update_post_meta( $post_id, '_vf_id', $id );
			}

		}

	}


	/**
	 * Get attachment ID.
	 *
	 * @param  string $url        Attachment URL.
	 * @param  int    $product_id Product ID.
	 * @return int
	 * @throws Exception If attachment cannot be loaded.
	 */
	function get_attachment_id_from_url_viztech( $url, $product_id = 0 ) {
		
		if ( empty( $url ) ) {
			return 0;
		}

		$id         = 0;
		$base_url = get_option('wpt_url_site_api') . 'wp-content/uploads/';

		$file = str_replace( $base_url, '', $url );

		$args = array(
			'post_type'   => 'attachment',
			'post_status' => 'any',
			'fields'      => 'ids',
			'meta_query'  => array( // @codingStandardsIgnoreLine.
				'relation' => 'OR',
				array(
					'key'     => '_wp_attached_file',
					'value'   => '^' . $file,
					'compare' => 'REGEXP',
				),
				array(
					'key'     => '_wp_attached_file',
					'value'   => $file,
					'compare' => 'LIKE',
				),
				array(
					'value' => $file,
					'key'   => '_wc_attachment_source',
					'compare'   => 'LIKE',
				),
			),
		);
			
		$ids = get_posts( $args ); // @codingStandardsIgnoreLine.

		if ( $ids ) {
			$id = current( $ids );
		}

		// Upload if attachment does not exists.
		if ( ! $id && stristr( $url, '://' ) ) {
			$upload = wc_rest_upload_image_from_url( $url );

			if ( is_wp_error( $upload ) ) {
				throw new Exception( $upload->get_error_message(), 400 );
			}

			$id = wc_rest_set_uploaded_image_as_attachment( $upload, $product_id );

			if ( ! wp_attachment_is_image( $id ) ) {
				/* translators: %s: image URL */
				throw new Exception( sprintf( __( 'Not able to attach "%s".', 'woocommerce' ), $url ), 400 );
			}

			// Save attachment source for future reference.
			update_post_meta( $id, '_wc_attachment_source', $url );

		}

		if ( ! $id ) {
			/* translators: %s: image URL */
			throw new Exception( sprintf( __( 'Unable to use image "%s".', 'woocommerce' ), $url ), 400 );
		}

		return $id;
	}

	function post_exists_viztech( $title, $content = '', $date = '', $type = '', $status = '' ) {
        global $wpdb;
     
        $post_title   = wp_unslash( sanitize_post_field( 'post_title', $title, 0, 'db' ) );
        $post_content = wp_unslash( sanitize_post_field( 'post_content', $content, 0, 'db' ) );
        $post_date    = wp_unslash( sanitize_post_field( 'post_date', $date, 0, 'db' ) );
        $post_type    = wp_unslash( sanitize_post_field( 'post_type', $type, 0, 'db' ) );
        $post_status  = wp_unslash( sanitize_post_field( 'post_status', $status, 0, 'db' ) );
     
        $query = "SELECT ID FROM $wpdb->posts WHERE 1=1";
        $args  = array();
     
        if ( ! empty( $date ) ) {
            $query .= ' AND post_date = %s';
            $args[] = $post_date;
        }
     
        if ( ! empty( $title ) ) {
            $query .= ' AND post_title = %s';
            $args[] = $post_title;
        }
     
        if ( ! empty( $content ) ) {
            $query .= ' AND post_content = %s';
            $args[] = $post_content;
        }
     
        if ( ! empty( $type ) ) {
            $query .= ' AND post_type = %s';
            $args[] = $post_type;
        }
     
        if ( ! empty( $status ) ) {
            $query .= ' AND post_status = %s';
            $args[] = $post_status;
        }
     
        if ( ! empty( $args ) ) {
            return (int) $wpdb->get_var( $wpdb->prepare( $query, $args ) );
        }
     
        return 0;
    }

	
}


new viztech_api_format_products();


?>