<?php

require_once 'vendor/autoload.php';
require_once plugin_dir_path( __DIR__ ) . 'lib/class-viztech-api-format-products.php';

use chillerlan\QRCode\QRCode;
use chillerlan\QRCode\QROptions;



class Threed_Product_Viewer_Public {

    /**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;


    public function __construct( $plugin_name, $version ) {

        $this->plugin_name = $plugin_name;
		$this->version = $version;
		
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles') );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts') );
		add_filter( 'script_loader_tag', array( $this, 'change_js_type_module'), 10, 3 );
		add_filter( 'woocommerce_single_product_image_thumbnail_html', array($this, 'custom_woocommerce_single_product_image_thumbnail_html'), 10, 2 );
		add_action('activate_threed_ac', array( $this, 'format_threed_content') );
		add_filter( 'woocommerce_single_product_carousel_options', array( $this, 'filter_single_product_carousel_options') );
		add_filter( 'body_class', array($this, 'my_body_classes') );
		add_action('wp_head', array($this, 'add_no_script') );
	}

    /**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Threed_Product_Viewer_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Threed_Product_Viewer_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		$threed = $this->check_if_threed(); 

		if ( false !== $threed ) {
			wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/threed-product-viewer-public.css', array(), $this->version, 'all' );

			wp_enqueue_style( $this->plugin_name . '-img-viewer', plugin_dir_url( __FILE__ ) . 'threesixtyjs-master/assets/css/main.css', array(), $this->version, 'all' );
			
		}
		
		

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Threed_Product_Viewer_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Threed_Product_Viewer_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		$threed = $this->check_if_threed(); 

		if ( false !== $threed ) {
			
			wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/threed-product-viewer-public.js', array( 'jquery' ), $this->version, false );

			wp_enqueue_script( $this->plugin_name . '-img-viewer', plugin_dir_url( __FILE__ ) . 'threesixtyjs-master/assets/js/jquery.threesixty.js', array( 'jquery' ), $this->version, false );

		}
	}




/**
	 * Return a model-viewer element given the source of the glb or gltf file.
	 * 
	 * @since 1.0.0
	 * @return type $qrcode: svg of qrcode to link of current page
	 */
	// public function create_qr_code(){
		
	// 	return $qrcode;
	// }
	/**
	 * Return a model-viewer element given the source of the glb or gltf file.
	 * 
	 * @since 1.0.0
	 * 
	 * @param string $file: the url of the glb or gltf
	 * @param bool $camera: whether the camera should be static or movable
	 * 
	 * @return string $markup: the markup of a model-viewer element on success and an error heading on failure.
	 */

				
	// Adding style manually here displays model-viewer in a correct size		
	private function get_model_view( $file='default', $camera = true ) {

		$file_parts = explode('.', $file);		
		ob_start();
		if ( 'default' === $file ) {
			?>
			<h2 class='model-viewer-error'>No file provided</h2>
			<?php
		} elseif ( !(in_array('glb', $file_parts)) && !(in_array('gltf', $file_parts)) ) {
			?>
			<h2 class='model-viewer-error'>Error, incorrect file type: <?php echo $file ?></h2>
			<?php
		} else {
			?>
			<model-viewer
				id='furniture-model'
				src=<?php echo $file ?>
				disable-pan
				touch-action="pan-y"
				loading='eager'
				min-camera-orbit='auto 35deg auto' 
				shadow-intensity='1' max-camera-orbit='auto 74deg auto'
				environment-image='https://viztech.s3.us-east-2.amazonaws.com/cgi/brown_photostudio_02_1k.hdr'
				
				<?php
				if ( $camera ) {
					?> camera-controls <?php
				}
				?>
				ar ar-modes='webxr scene-viewer quick-look'>
				<!-- Generate QR Code to link to mobile AR view -->
				<?php 
					$options = new QROptions(
						[
						'eccLevel' => QRCode::ECC_L,
						'outputType' => QRCode::OUTPUT_MARKUP_SVG,
						'version' => 5,
						]
					);
					
                 	// Get current page url to add to create QR code
					$current_url = get_permalink();

					// Generate SVG of QR code 
					$qrcode = (new QRCode($options))->render($current_url);
				?>
                        
					<!-- Modal to display QR Code -->
						<div class="modal-threed">
								<div class="modal-content-threed">
									<span class="close-button">×</span>
									<h2 style="text-align: center;">View Product in Your Space</h2>
									<p>Use your phone to scan the QR code to view the product in your room. Compatible with iPhone and Safari only.</p>
									<div class="qr-image">
										<img src="<?php echo $qrcode; ?>">
									</div>
								</div>
						</div>
						<!-- Mobile View AR Button Only --> 
						<button class="mobile-ar-button-style" id="ar-button-mobile" slot='ar-button'>View In Your Room</button>
					</model-viewer>
<!-- Desktop View AR Button Only --> 
<button class="trigger-threed ar-button-style" id="button_qr_modal">View in Room</button>
			<?php		

		}
		$markup = ob_get_clean();
		return $markup;
	}

	/**
	 * Generate a qr code to link to the product
	 * 
	 * @since 1.0.0

	 * @return type $qrcode: svg of qrcode to link of current page
	 */
	private function create_qr_code($page_url){
		// Generate QR Code to link to mobile AR view
		$options = new QROptions(
			[
			'eccLevel' => QRCode::ECC_L,
			'outputType' => QRCode::OUTPUT_MARKUP_SVG,
			'version' => 5,
			]
		);
		
		
		// Generate SVG of QR code 
		$qrcode = (new QRCode($options))->render($page_url);

		return $qrcode;
	}

	/**
	 * Changes the enqueue of the model-viewer js to type: module.
	 *
	 * @since 1.0.0
	 * 
	 * @param string $tag: the script tag that's going to get enqueued.
	 * @param string $handle: the slug of the script
	 * @param string $src: the script url
	 * 
	 * @return string $tag: the modified tag to be added to the page.
	 */
	public function change_js_type_module( $tag, $handle, $src ) {
		if ( 'threesixty-img-viewer-js' === $handle ) {
			$tag = '<script type="module" src="' . esc_url( $src ) . '"></script>';
		}
		if ( 'threesixty-img-viewer-css' === $handle ) {
			$tag = '<link  rel="stylesheet" href="' . esc_url( $src ) . '"></link>';
		}
		
		return $tag;
	}


	/**
	 * Summary.
	 *
	 * Description.
	 *
	 * @since x.x.x
	 *
	 * @see Function/method/class relied on
	 * @link URL
	 * @global type varname Description.
	 * @global type varname Description.
	 *
	 * @param type var Description.
	 * @param type var Optional. Description. Default.
	 * @return type Description.
	 */
	public function ws_get_gallery_image_html( $attachment_id, $main_image = false ) {
		$threed_thumb = json_decode(get_post_meta(get_the_ID(), 'threed_tab_content', true), true);
		$flexslider        = (bool) apply_filters( 'woocommerce_single_product_flexslider_enabled', get_theme_support( 'wc-product-gallery-slider' ) );
		$gallery_thumbnail = wc_get_image_size( 'gallery_thumbnail' );
		$thumbnail_size    = apply_filters( 'woocommerce_gallery_thumbnail_size', array( $gallery_thumbnail['width'], $gallery_thumbnail['height'] ) );
		$image_size        = apply_filters( 'woocommerce_gallery_image_size', $flexslider || $main_image ? 'woocommerce_single' : $thumbnail_size );
		$full_size         = apply_filters( 'woocommerce_gallery_full_size', apply_filters( 'woocommerce_product_thumbnails_large_size', 'full' ) );
		$thumbnail_src     = wp_get_attachment_image_src( $attachment_id, $thumbnail_size );
		$full_src          = wp_get_attachment_image_src( $attachment_id, $full_size );
		$alt_text          = trim( wp_strip_all_tags( get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) ) );
		$image             = wp_get_attachment_image(
			$attachment_id,
			$image_size,
			false,
			apply_filters(
				'woocommerce_gallery_image_html_attachment_image_params',
				array(
					'title'                   => _wp_specialchars( get_post_field( 'post_title', $attachment_id ), ENT_QUOTES, 'UTF-8', true ),
					'data-caption'            => _wp_specialchars( get_post_field( 'post_excerpt', $attachment_id ), ENT_QUOTES, 'UTF-8', true ),
					'data-src'                => esc_url( $full_src[0] ),
					'data-large_image'        => esc_url( $full_src[0] ),
					'data-large_image_width'  => esc_attr( $full_src[1] ),
					'data-large_image_height' => esc_attr( $full_src[2] ),
					'class'                   => esc_attr( $main_image ? 'wp-post-image' : '' ),
				),
				$attachment_id,
				$image_size,
				$main_image
			)	
		);
		
		// Woocommerce gallery image thumbnail placeholder
		$thumbnail = 'https://viztech.s3.us-east-2.amazonaws.com/cgi/360-Viewer-Thumbnail.jpg';
		
		// Load model-viewer code if the attachment id is generating a wc_gallery_image for a 3d thumbnail
		// Otherwise load a standard image for the gallery
		if ( (int) $attachment_id == (int) $threed_thumb['thumbnail_id']  ) {
		
			ob_start();
				?>

<div class="threesixty-wrapper" data-glb-url="<?php echo $threed_thumb['glb_url']; ?>" data-usdz-url="<?php echo $threed_thumb['usdz_url']; ?>">

					<div class="threesixty" data-path="<?php echo $threed_thumb['threesixty_url']; ?>" data-count="32">
						<!-- put your preloader here -->
						<div class="ui-spinner">
							<span class="side side-left">
								<span class="fill"></span>
							</span>
							<span class="side side-right">
								<span class="fill"></span>
							</span>
							
						</div>
						<!-- end preloader -->
					</div>
					<img id="threesixtyicon" src="https://viztech.s3.us-east-2.amazonaws.com/cgi/360-Viewer-Icon.png">
							
					<?php 
						// Get current page url to add to create QR code
						$current_url = get_permalink();
						$qrcode = $this->create_qr_code($current_url);
					?>

					<!-- Modal to display QR Code -->
					<div class="modal-threed">
							<div class="modal-content-threed">
								<span class="close-button">×</span>
								<h2>View Product in Your Space </h2>
								<p>Use your phone or tablet to scan the QR code to view the product in your room.</p>
								<div class="qr-image" >
									<img src="<?php echo $qrcode; ?>">
								</div>
							</div>
					</div>
				</div>				
			
				<button class="trigger-threed ar-button-style" id="qr_modal_button">VIEW IN MY ROOM</button>
				
				<script>
					(function($){
					$(document).ready(function(){

						var $threeSixty = $('.threesixty');

						$threeSixty.threeSixty({
							dragDirection: 'horizontal',
							useKeys: false,
							draggable: true
						});

					});
				})(jQuery);
				</script>
			<?php
			$val = ob_get_clean();
			
			// Hardcoded url parameter for the glb file 
			// $val .= $this->get_model_view($threed_thumb['threed_model_url']);
			return '<div data-thumb="' .  esc_url( $thumbnail ) . '" data-thumb-alt="' . esc_attr( $alt_text ) . '" class="woocommerce-product-gallery__image"><div> '. $val .'</div></div>';
		} 	
		else {
			return '<div data-thumb="' . esc_url( $thumbnail_src[0] ) . '" data-thumb-alt="' . esc_attr( $alt_text ) . '" class="woocommerce-product-gallery__image"><a data-lightbox="Gallery" href="' . esc_url($full_src[0]) . '">' . $image . '</a></div>';
		}

	}

	/**
	 * Summary.
	 *
	 * Description.
	 *
	 * @since x.x.x
	 *
	 * @see Function/method/class relied on
	 * @link URL
	 * @global type varname Description.
	 * @global type varname Description.
	 *
	 * @param type var Description.
	 * @param type var Optional. Description. Default.
	 * @return type Description.
	 */
	public function custom_woocommerce_single_product_image_thumbnail_html( $html, $post_thumbnail_id ) {

       $threed = $this->check_if_threed(); 

		if ( false !== $threed ) {

            $html = $this->ws_get_gallery_image_html( $post_thumbnail_id, true );

        }
		
		return $html;
	}


	function format_threed_content() {

		$formatting_prods = new viztech_api_format_products();

		$args = array(
			'meta_key' 		=>  'threed_tab_content',
			'post_type' 	=>  'product',
			'post_status'	=>  'publish',
			'fields'		=>  'ids',
			'posts_per_page' => -1,
		 );
		 
		 $query = get_posts($args);
		
		 foreach ( $query as $prod_id ) {
		
			$get_json = json_decode(get_post_meta($prod_id, 'threed_tab_content', true),true);
		
			$exists = $get_json['thumbnail_id'];

			if ( empty($exists) ) {
		
				$thumbnail_src = 'https://viztech.s3.us-east-2.amazonaws.com/cgi/360-Viewer-Thumbnail.jpg';
		
				$placeholder_image = $formatting_prods->get_attachment_id_from_url_viztech($thumbnail_src);
		
				$product = wc_get_product($prod_id);
				
				$gallery_images = $product->get_gallery_image_ids();

				$gallery_images = ! empty( $gallery_images ) ? $gallery_images : array();
		
				$new_gallery_images = array();

				if ( ! in_array( $placeholder_image, $gallery_images ) ) {
		
					if ( empty($gallery_images) ) {
						$gallery_images[] = $placeholder_image;
					} else {
						$new_gallery_images[] = $placeholder_image;
					}

				}

				if ( ! empty($new_gallery_images) ) {
					array_splice( $gallery_images, 0, 0, $new_gallery_images ); // splice in at position 1	
				}

				$get_json['thumbnail_id'] = $placeholder_image;
	
				$product->set_gallery_image_ids( $gallery_images );
		
				$product->save();
			
				update_post_meta($prod_id, 'threed_tab_content', json_encode($get_json));
				
			}
				
		 }

	}

	private function check_if_threed() {

		$threed = false;

		if ( is_product() ) {

			$get_threed = get_post_meta(get_the_ID(), 'threed_tab_content', true);

			if ( isset($get_threed) && ! empty($get_threed) ) {
				$threed = true;
			}

		}

		return $threed;

	}


	function filter_single_product_carousel_options( $args ) {
	
		$threed = $this->check_if_threed();

		if ( true === $threed ) {
			$args['touch'] = false;
		}

		return $args;
	}

	function my_body_classes( $classes ) {
		
		$threed = $this->check_if_threed();

		if ( true === $threed ) {
			$classes[] = 'threed';
		}
		
		return $classes;
		
	}


	function add_no_script() {
	
		$threed = $this->check_if_threed();

		if ( true === $threed ) {
		?>
		<noscript><style>#button_qr_modal, #ar-button-mobile, #mobile-button-container { display: none !important; }</style></noscript>
		<?php
		
		}
	}


}	

?>