jQuery(document).ready(function(){
    
      jQuery('#first_hidden').parent().parent().addClass("hideme");
  
      jQuery('#last_hidden').parent().parent().addClass("hideme");
      
  
      jQuery("[id^=vf_increase_price_builder]").parent().parent().addClass('hideme builder_increase');
  
      jQuery( ".increase_builder_prices" ).click(function(e) {
              
              e.preventDefault();
  
              jQuery('.builder_increase').toggleClass('hideme');
  
        });
  
        jQuery('#vf_sync_everything').click(function() {
  
            if ( jQuery(this).is( ':checked' ) ) {
                 jQuery('#vf_builders').attr('disabled', 'true');
            } else {
                  jQuery('#vf_builders').removeAttr('disabled');
            }
            
  
        });
  
  });