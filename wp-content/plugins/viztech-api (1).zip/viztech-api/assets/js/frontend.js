/**
 * Plugin Template frontend js.
 *
 *  @package WordPress Plugin Template/JS
 */

jQuery( document ).ready(
	function ( e ) {

		var swatch_scroll_position;

		jQuery(".swatches-lightbox-link").click(function (event) {
		  var image = jQuery(this).attr("href");
		  var caption = jQuery(this).attr("data-caption");
		  var html = "<img src='" + image + "' ><p>" + caption + "</p>";
		  jQuery(".swatches-lightbox-content-img").html(html);
		  jQuery(".swatches-lightbox").show();
		  jQuery("body").css("overflow", "hidden");
		  swatch_scroll_position = jQuery(window).scrollTop();
		});
	
		jQuery(".swatches-lightbox-close").click(function () {
		  jQuery(".swatches-lightbox").hide();
		  jQuery("body").removeAttr("style");
		  setTimeout(function () {
			jQuery(window).scrollTop(swatch_scroll_position);
		  }, 1);
		});
	

	}
);
